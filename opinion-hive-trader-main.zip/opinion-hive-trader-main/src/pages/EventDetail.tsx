import React, { useState } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Share2, Lightbulb, Clock, Users, ChevronDown, Info, Settings, BarChart, Handshake } from 'lucide-react';
import { motion } from 'framer-motion';
import BottomNavigation from '@/components/BottomNavigation';
import { Line, LineChart, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { useToast } from '@/hooks/use-toast';

// Mock event data
const eventData = {
  id: '1',
  title: 'Mumbai to win the match vs Bengaluru?',
  shortTitle: 'MUM vs BLR',
  category: 'Cricket',
  image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTZ7QJhG8ixIKfpfouVKAJHFvABGeNMSQKlzA&usqp=CAU',
  hint: 'Mumbai 3, Bengaluru 2, DRAW 0',
  yesPrice: '6.0',
  noPrice: '4.0',
  traders: 414,
  volume: '₹20676',
  availableQuantity: 120,
  startTime: '10 Mar, 11:35 PM',
  endTime: '11 Mar, 11:50 PM',
  probability: 55,
  chartData: Array.from({ length: 24 }, (_, i) => ({
    time: `${i}:00`,
    value: 50 + Math.sin(i * 0.5) * 20 + Math.random() * 10 - 5
  })),
  sourceOfTruth: 'The final score as reported by the official cricket board website will be used to determine the outcome.',
  expiryDetails: 'This event will expire at 11:50 PM IST on March 11, 2023. Any trades after this time will not be settled.',
  settlementRules: 'All trades will be settled within 24 hours after the event has concluded. Winnings will be credited directly to your wallet balance.'
};

// Mock trading activity with matched pairs
const tradingActivity = [
  { 
    id: '1', 
    user: 'arishadbhat161', 
    avatar: null, 
    yesPrice: '₹6', 
    noPrice: '₹4', 
    time: 'a few seconds ago', 
    userInitial: 'A', 
    side: 'yes',
    matchedWith: {
      user: 'paapiaadmi918',
      avatar: null,
      userInitial: 'P',
      side: 'no'
    }
  },
  { 
    id: '2', 
    user: 'tinkukumar293', 
    avatar: '/lovable-uploads/315d0e99-d92d-4acc-af2c-716e30f049b5.png', 
    yesPrice: '₹6', 
    noPrice: '₹4', 
    time: '2 minutes ago', 
    side: 'yes',
    matchedWith: {
      user: 'rupeshkumar435',
      avatar: null,
      userInitial: 'R',
      side: 'no'
    }
  },
  { 
    id: '3', 
    user: 'paapiaadmi918', 
    avatar: null, 
    yesPrice: '₹5.5', 
    noPrice: '₹4.5', 
    time: '5 minutes ago', 
    userInitial: 'P', 
    side: 'yes'
  },
  { 
    id: '4', 
    user: 'amitkumaryad', 
    avatar: '/lovable-uploads/6ef4d54f-9681-45c3-b14b-cce15b1bdd8b.png', 
    yesPrice: '₹5.5', 
    noPrice: '₹4.5', 
    time: '10 minutes ago', 
    side: 'no'
  },
  { 
    id: '5', 
    user: 'rupeshkumar435', 
    avatar: null, 
    yesPrice: '₹8', 
    noPrice: '₹2', 
    time: '15 minutes ago', 
    userInitial: 'R', 
    side: 'yes'
  },
];

// Mock order book data
const orderBookData = {
  yes: [
    { price: 6.5, amount: 35 },
    { price: 6.2, amount: 42 },
    { price: 6.0, amount: 75 },
    { price: 5.8, amount: 28 },
  ],
  no: [
    { price: 3.8, amount: 31 },
    { price: 4.0, amount: 56 },
    { price: 4.2, amount: 27 },
    { price: 4.5, amount: 18 },
  ]
};

const EventDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [activeTab, setActiveTab] = useState<'activity' | 'orderbook'>('activity');
  const [timeframe, setTimeframe] = useState<'1h' | '6h' | '12h' | 'all'>('1h');
  const [expandedSection, setExpandedSection] = useState<string | null>(null);
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const handleTabChange = (tab: 'activity' | 'orderbook') => {
    setActiveTab(tab);
  };
  
  const toggleSection = (section: string) => {
    if (expandedSection === section) {
      setExpandedSection(null);
    } else {
      setExpandedSection(section);
    }
  };
  
  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast({
      title: "Link copied",
      description: "Event link copied to clipboard",
    });
  };
  
  const handleTrade = (type: 'yes' | 'no') => {
    navigate(`/trade-match/${id}?side=${type}`);
  };
  
  return (
    <div className="min-h-screen bg-gray-50 pb-16">
      {/* Header */}
      <header className="bg-white p-4 flex items-center justify-between shadow-sm">
        <Link to="/" className="text-gray-700">
          <ArrowLeft size={22} />
        </Link>
        <h1 className="text-lg font-semibold">{eventData.shortTitle}</h1>
        <button onClick={handleShare} className="text-gray-700">
          <Share2 size={22} />
        </button>
      </header>
      
      {/* Event Details */}
      <div className="p-4 bg-white mb-4">
        <div className="flex items-center justify-center mb-4">
          <div className="w-16 h-16 rounded-lg overflow-hidden">
            <img src={eventData.image} alt={eventData.category} className="w-full h-full object-cover" />
          </div>
        </div>
        
        <div className="text-center">
          <div className="inline-block px-3 py-1 bg-gray-100 rounded-full text-sm text-gray-700 mb-2">
            {eventData.shortTitle}
          </div>
          <h1 className="text-xl font-semibold text-center mb-2">{eventData.title}</h1>
          
          <div className="flex items-center justify-center text-sm text-amber-600 mb-4">
            <div className="flex items-center gap-1 bg-amber-50 px-3 py-1 rounded-full">
              <Lightbulb className="w-4 h-4 text-amber-500" />
              <span>{eventData.hint}</span>
            </div>
          </div>
          
          {/* Yes/No probability */}
          <div className="mb-4">
            <div className="bg-blue-500 text-white px-3 py-2 rounded-lg mb-2 flex items-center gap-2">
              <span className="rotate-180">↔</span>
              <span className="font-medium">YES</span>
              <span className="ml-auto font-semibold">{eventData.probability}% Probability</span>
              <span className="text-xs text-blue-200">-6.8% 1h</span>
            </div>
            
            <div className="flex items-center justify-between text-sm">
              <button className={`px-2 py-1 ${timeframe === '1h' ? 'font-semibold border-b-2 border-blue-500' : 'text-gray-500'}`} onClick={() => setTimeframe('1h')}>1 h</button>
              <button className={`px-2 py-1 ${timeframe === '6h' ? 'font-semibold border-b-2 border-blue-500' : 'text-gray-500'}`} onClick={() => setTimeframe('6h')}>6 h</button>
              <button className={`px-2 py-1 ${timeframe === '12h' ? 'font-semibold border-b-2 border-blue-500' : 'text-gray-500'}`} onClick={() => setTimeframe('12h')}>12 h</button>
              <button className={`px-2 py-1 ${timeframe === 'all' ? 'font-semibold border-b-2 border-blue-500' : 'text-gray-500'}`} onClick={() => setTimeframe('all')}>All</button>
            </div>
            
            {/* Chart for value graph */}
            <div className="h-40 my-2">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={eventData.chartData}>
                  <XAxis 
                    dataKey="time" 
                    tick={{ fontSize: 10 }} 
                    tickFormatter={(value) => value.replace(':00', '')}
                    interval={Math.floor(eventData.chartData.length / 6)}
                  />
                  <YAxis 
                    domain={[0, 100]} 
                    hide={true}
                  />
                  <Tooltip 
                    formatter={(value) => [`${value}%`, 'Probability']}
                    labelFormatter={(label) => `Time: ${label}`}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="value" 
                    stroke="#3b82f6" 
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
          
          {/* Trading buttons */}
          <div className="grid grid-cols-2 gap-3 mb-4">
            <button 
              onClick={() => handleTrade('yes')}
              className="py-3 rounded-lg bg-blue-50 text-blue-500 font-medium"
            >
              Yes ₹{eventData.yesPrice}
            </button>
            <button 
              onClick={() => handleTrade('no')}
              className="py-3 rounded-lg bg-red-50 text-red-500 font-medium"
            >
              No ₹{eventData.noPrice}
            </button>
          </div>
        </div>
      </div>
      
      {/* About This Event */}
      <div className="bg-white mb-4">
        <h2 className="px-4 py-3 text-xl font-semibold">About This Event</h2>
        
        <div className="grid grid-cols-2 divide-x divide-gray-100 border-t border-gray-100">
          <div className="px-4 py-3">
            <p className="text-sm text-gray-500">Traders</p>
            <p className="text-lg font-medium">{eventData.traders}</p>
          </div>
          <div className="px-4 py-3">
            <p className="text-sm text-gray-500">Volume</p>
            <p className="text-lg font-medium">{eventData.volume}</p>
          </div>
        </div>
        
        <div className="grid grid-cols-2 divide-x divide-gray-100 border-t border-gray-100">
          <div className="px-4 py-3">
            <p className="text-sm text-gray-500">Start Time</p>
            <p className="text-lg font-medium">{eventData.startTime}</p>
          </div>
          <div className="px-4 py-3">
            <p className="text-sm text-gray-500">End Time</p>
            <p className="text-lg font-medium">{eventData.endTime}</p>
          </div>
        </div>
        
        <div className="grid grid-cols-2 divide-x divide-gray-100 border-t border-gray-100">
          <div className="px-4 py-3">
            <p className="text-sm text-gray-500">Available Quantity</p>
            <p className="text-lg font-medium">{eventData.availableQuantity}</p>
          </div>
          <div className="px-4 py-3">
            <p className="text-sm text-gray-500">Total Volume</p>
            <div className="flex items-center">
              <p className="text-lg font-medium">{eventData.volume}</p>
              <BarChart className="ml-2 w-5 h-5 text-gray-400" />
            </div>
          </div>
        </div>
      </div>
      
      {/* Accordion sections */}
      <div className="bg-white mb-4">
        <div 
          className="px-4 py-3 border-b border-gray-100 flex items-center cursor-pointer"
          onClick={() => toggleSection('sourceOfTruth')}
        >
          <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center mr-3">
            <Info className="w-4 h-4 text-purple-600" />
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-medium">Source of Truth</h3>
            <p className="text-sm text-gray-500">Details of the source of predictions</p>
          </div>
          <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform ${expandedSection === 'sourceOfTruth' ? 'transform rotate-180' : ''}`} />
        </div>
        
        {expandedSection === 'sourceOfTruth' && (
          <div className="px-4 py-3 bg-gray-50 text-sm text-gray-700">
            {eventData.sourceOfTruth}
          </div>
        )}
        
        <div 
          className="px-4 py-3 border-b border-gray-100 flex items-center cursor-pointer"
          onClick={() => toggleSection('expiry')}
        >
          <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-3">
            <Clock className="w-4 h-4 text-blue-600" />
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-medium">Expiry</h3>
            <p className="text-sm text-gray-500">Event expiry details</p>
          </div>
          <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform ${expandedSection === 'expiry' ? 'transform rotate-180' : ''}`} />
        </div>
        
        {expandedSection === 'expiry' && (
          <div className="px-4 py-3 bg-gray-50 text-sm text-gray-700">
            {eventData.expiryDetails}
          </div>
        )}
        
        <div 
          className="px-4 py-3 flex items-center cursor-pointer"
          onClick={() => toggleSection('settlement')}
        >
          <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center mr-3">
            <Settings className="w-4 h-4 text-red-600" />
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-medium">Settlement</h3>
            <p className="text-sm text-gray-500">Details of the event settlement</p>
          </div>
          <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform ${expandedSection === 'settlement' ? 'transform rotate-180' : ''}`} />
        </div>
        
        {expandedSection === 'settlement' && (
          <div className="px-4 py-3 bg-gray-50 text-sm text-gray-700">
            {eventData.settlementRules}
          </div>
        )}
      </div>
      
      {/* Trading Tagline */}
      <div className="px-4 py-6 bg-white mb-4">
        <h2 className="text-4xl font-bold text-gray-300">Keep Trading!</h2>
        <p className="text-gray-500 mt-2">Opinion hai to Winox par do</p>
      </div>
      
      {/* Activity/Order Book Tabs */}
      <div className="bg-white pb-4">
        <div className="flex border-b border-gray-200">
          <button
            className={`flex-1 py-3 text-center font-medium ${
              activeTab === 'activity' 
                ? 'text-black border-b-2 border-black' 
                : 'text-gray-500'
            }`}
            onClick={() => handleTabChange('activity')}
          >
            Activity
          </button>
          <button
            className={`flex-1 py-3 text-center font-medium ${
              activeTab === 'orderbook' 
                ? 'text-black border-b-2 border-black' 
                : 'text-gray-500'
            }`}
            onClick={() => handleTabChange('orderbook')}
          >
            Order Book
          </button>
        </div>
        
        {/* Trading Activity */}
        {activeTab === 'activity' && (
          <div className="divide-y divide-gray-100">
            {tradingActivity.map(activity => (
              <div key={activity.id} className="px-4 py-3">
                {activity.matchedWith ? (
                  <div className="p-3 bg-blue-50 rounded-lg mb-2">
                    <div className="flex items-center mb-2">
                      <Handshake className="w-4 h-4 text-blue-500 mr-1" />
                      <p className="text-sm font-medium text-blue-700">Trade Match</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex flex-col items-center">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          activity.side === 'yes' ? 'border-2 border-blue-500' : 'border-2 border-red-500'
                        }`}>
                          {activity.avatar ? (
                            <img src={activity.avatar} alt={activity.user} className="w-full h-full rounded-full object-cover" />
                          ) : (
                            <div className="w-full h-full rounded-full bg-blue-500 flex items-center justify-center">
                              <span className="text-white font-semibold">{activity.userInitial}</span>
                            </div>
                          )}
                        </div>
                        <div className={`mt-1 px-2 py-0.5 rounded-full text-xs ${
                          activity.side === 'yes' ? 'bg-blue-100 text-blue-600' : 'bg-red-100 text-red-600'
                        }`}>
                          {activity.side === 'yes' ? 'YES' : 'NO'}
                        </div>
                      </div>
                      
                      <div className="flex-1 text-center">
                        <div className="border-t-2 border-dashed border-gray-400 mx-1"></div>
                      </div>
                      
                      <div className="flex flex-col items-center">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          activity.matchedWith.side === 'yes' ? 'border-2 border-blue-500' : 'border-2 border-red-500'
                        }`}>
                          {activity.matchedWith.avatar ? (
                            <img src={activity.matchedWith.avatar} alt={activity.matchedWith.user} className="w-full h-full rounded-full object-cover" />
                          ) : (
                            <div className="w-full h-full rounded-full bg-red-500 flex items-center justify-center">
                              <span className="text-white font-semibold">{activity.matchedWith.userInitial}</span>
                            </div>
                          )}
                        </div>
                        <div className={`mt-1 px-2 py-0.5 rounded-full text-xs ${
                          activity.matchedWith.side === 'yes' ? 'bg-blue-100 text-blue-600' : 'bg-red-100 text-red-600'
                        }`}>
                          {activity.matchedWith.side === 'yes' ? 'YES' : 'NO'}
                        </div>
                      </div>
                    </div>
                    <div className="flex justify-between mt-2 text-sm">
                      <p className="text-gray-700">{activity.user}</p>
                      <p className="text-gray-700">{activity.matchedWith.user}</p>
                    </div>
                    <div className="mt-1 text-xs text-gray-500 text-center">
                      <Clock className="inline w-3 h-3 mr-1" />
                      {activity.time}
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                      activity.side === 'yes' ? 'border-2 border-blue-500' : 'border-2 border-red-500'
                    }`}>
                      {activity.avatar ? (
                        <img src={activity.avatar} alt={activity.user} className="w-full h-full rounded-full object-cover" />
                      ) : (
                        <div className="w-full h-full rounded-full bg-blue-500 flex items-center justify-center">
                          <span className="text-white font-semibold">{activity.userInitial}</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="ml-3 flex-1">
                      <p className="font-medium">{activity.user}</p>
                      <p className="text-sm text-gray-500">{activity.time}</p>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <div className="px-3 py-1 bg-blue-50 text-blue-500 rounded-md">
                        {activity.yesPrice}
                      </div>
                      <div className="px-3 py-1 bg-red-50 text-red-500 rounded-md">
                        {activity.noPrice}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
        
        {/* Order Book */}
        {activeTab === 'orderbook' && (
          <div className="p-4">
            <div className="mb-4">
              <h3 className="text-lg font-medium text-blue-500 mb-2">Yes Orders</h3>
              <div className="bg-blue-50 rounded-lg p-2">
                <div className="grid grid-cols-2 py-2 font-medium">
                  <div className="text-center">Price</div>
                  <div className="text-center">Amount</div>
                </div>
                {orderBookData.yes.map((order, index) => (
                  <div key={index} className="grid grid-cols-2 py-2 border-t border-blue-100">
                    <div className="text-center font-medium">₹{order.price.toFixed(1)}</div>
                    <div className="text-center">{order.amount}</div>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-medium text-red-500 mb-2">No Orders</h3>
              <div className="bg-red-50 rounded-lg p-2">
                <div className="grid grid-cols-2 py-2 font-medium">
                  <div className="text-center">Price</div>
                  <div className="text-center">Amount</div>
                </div>
                {orderBookData.no.map((order, index) => (
                  <div key={index} className="grid grid-cols-2 py-2 border-t border-red-100">
                    <div className="text-center font-medium">₹{order.price.toFixed(1)}</div>
                    <div className="text-center">{order.amount}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Trading buttons fixed at bottom */}
      <div className="fixed bottom-16 left-0 right-0 grid grid-cols-2 gap-3 p-3 bg-white border-t border-gray-200">
        <button 
          onClick={() => handleTrade('yes')}
          className="py-3 rounded-lg bg-blue-50 text-blue-500 font-medium"
        >
          Yes ₹{eventData.yesPrice}
        </button>
        <button 
          onClick={() => handleTrade('no')}
          className="py-3 rounded-lg bg-red-50 text-red-500 font-medium"
        >
          No ₹{eventData.noPrice}
        </button>
      </div>
      
      <BottomNavigation activeTab="home" />
    </div>
  );
};

export default EventDetail;
