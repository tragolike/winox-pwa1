
import React, { useState, useEffect } from 'react';
import { ArrowLeft, Search as SearchIcon } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import BottomNavigation from '@/components/BottomNavigation';

// Mock data for events (same as in Home.tsx)
const allEvents = [
  {
    id: '1',
    category: 'Cricket',
    title: 'Mumbai Women to win the match vs Bengaluru Women?',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTZ7QJhG8ixIKfpfouVKAJHFvABGeNMSQKlzA&usqp=CAU',
    hint: 'H2H last 5 T20: Mumbai 3, Bengaluru 2, DRAW 0',
    yesPrice: '5.5',
    noPrice: '4.5',
    endTime: '11 Mar, 11:50 PM',
    traders: 414,
    volume: '₹20676',
  },
  {
    id: '2',
    category: 'Cricket',
    title: 'West Indies Masters to win the match vs South Africa Masters?',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYnZ-eFOr-LE8g2TfRgpHPLZG3jVvEj03j0g&usqp=CAU',
    yesPrice: '6.0',
    noPrice: '4.0',
    endTime: '12 Mar, 2:30 AM',
    traders: 211,
    volume: '₹12540',
  },
  {
    id: '3',
    category: 'Crypto',
    title: 'Bitcoin is forecasted to reach at 77655.25 USDT or more at 01:30 AM?',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRGIISxP2K_qgFRTc0-GQ6tHiUUmAwiO9BHrQ&usqp=CAU',
    hint: 'Price at 12:30 AM was 77655.25 USDT',
    yesPrice: '5.0',
    noPrice: '5.0',
    endTime: '11 Mar, 1:30 AM',
    traders: 190,
    volume: '₹9320',
  },
  {
    id: '4',
    category: 'Growth',
    title: 'Will India\'s GDP growth surpass 7.5% this quarter?',
    image: '/lovable-uploads/2a62c269-ad28-4d72-a043-ea9ba3881836.png',
    yesPrice: '7.2',
    noPrice: '2.8',
    endTime: '15 Mar, 6:00 PM',
    traders: 328,
    volume: '₹15420',
  },
];

const Search = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState(allEvents);

  useEffect(() => {
    if (query.trim() === '') {
      setResults(allEvents);
    } else {
      const filteredResults = allEvents.filter(event => 
        event.title.toLowerCase().includes(query.toLowerCase()) ||
        event.category.toLowerCase().includes(query.toLowerCase())
      );
      setResults(filteredResults);
    }
  }, [query]);

  return (
    <div className="min-h-screen bg-gray-50 pb-16">
      <header className="bg-white p-4 flex items-center justify-between shadow-sm">
        <Link to="/" className="text-gray-700">
          <ArrowLeft size={22} />
        </Link>
        <h1 className="text-xl font-semibold">Search Events</h1>
        <div className="w-5"></div>
      </header>
      
      {/* Search Bar */}
      <div className="px-4 pt-4 pb-2">
        <div className="relative">
          <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
          <input
            type="text"
            placeholder="Search events, categories, etc..."
            className="w-full bg-white border border-gray-200 rounded-full py-2.5 pl-10 pr-4 text-sm"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
          />
        </div>
      </div>
      
      {/* Results */}
      <div className="px-4 pt-2">
        <h2 className="text-lg font-bold mb-3">
          {query ? `Results for "${query}"` : "All Events"}
        </h2>
        
        {results.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-gray-500">No events found matching your search</p>
          </div>
        ) : (
          <div className="space-y-4">
            {results.map(event => (
              <Link key={event.id} to={`/event/${event.id}`} className="block">
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white rounded-xl overflow-hidden shadow-sm p-4"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0">
                      <img src={event.image} alt={event.category} className="w-full h-full object-cover" />
                    </div>
                    
                    <div className="flex-1">
                      <p className="text-xs text-blue-500 font-medium">{event.category}</p>
                      <h3 className="font-medium text-gray-900 mb-1">{event.title}</h3>
                      
                      <div className="flex items-center text-xs text-gray-500 mb-2">
                        <span className="mr-2">Volume: {event.volume}</span>
                        <span>|</span>
                        <span className="mx-2">Ends: {event.endTime}</span>
                      </div>
                      
                      <div className="flex gap-2 mt-2">
                        <div className="flex-1 py-2 rounded-lg bg-blue-50 text-blue-500 font-medium text-sm text-center">
                          Yes ₹{event.yesPrice}
                        </div>
                        <div className="flex-1 py-2 rounded-lg bg-red-50 text-red-500 font-medium text-sm text-center">
                          No ₹{event.noPrice}
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              </Link>
            ))}
          </div>
        )}
      </div>
      
      <BottomNavigation activeTab="search" />
    </div>
  );
};

export default Search;
