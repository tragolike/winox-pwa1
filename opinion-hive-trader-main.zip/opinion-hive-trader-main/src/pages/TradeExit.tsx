
import React, { useState, useEffect } from 'react';
import { ArrowLeft, CheckCircle, IndianRupee, UserRound, Handshake } from 'lucide-react';
import { Link, useParams, useLocation, useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { motion } from 'framer-motion';
import { useAuth } from '@/hooks/useAuth';

// Mock event data
const events = {
  '1': {
    id: '1',
    title: 'Mumbai to win the match vs Bengaluru?',
    shortTitle: 'MUM vs BLR',
    category: 'Cricket',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTZ7QJhG8ixIKfpfouVKAJHFvABGeNMSQKlzA&usqp=CAU',
  },
  '2': {
    id: '2',
    title: 'West Indies Masters to win the match vs South Africa Masters?',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYnZ-eFOr-LE8g2TfRgpHPLZG3jVvEj03j0g&usqp=CAU',
    shortTitle: 'WI-M vs SA-M',
    category: 'Cricket',
  },
  '3': {
    id: '3',
    title: 'Bitcoin to reach 77655.25 USDT?',
    shortTitle: 'BTC Prediction',
    category: 'Crypto',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRGIISxP2K_qgFRTc0-GQ6tHiUUmAwiO9BHrQ&usqp=CAU',
  },
  '4': {
    id: '4',
    title: 'India\'s GDP growth to surpass 7.5%?',
    shortTitle: 'GDP Growth',
    category: 'Economy',
    image: '/lovable-uploads/2a62c269-ad28-4d72-a043-ea9ba3881836.png',
  }
};

// Mock trading partners data
const tradingPartners = {
  '1': { 
    username: 'arishadbhat161', 
    avatar: null,
    userInitial: 'A',
    side: 'no'
  },
  '2': { 
    username: 'tinkukumar293', 
    avatar: '/lovable-uploads/315d0e99-d92d-4acc-af2c-716e30f049b5.png', 
    userInitial: 'T',
    side: 'no'
  },
  '3': { 
    username: 'rupeshkumar435', 
    avatar: null, 
    userInitial: 'R',
    side: 'yes'
  }
};

const TradeExit = () => {
  const { id } = useParams<{ id: string }>();
  const location = useLocation();
  const navigate = useNavigate();
  const [tradeCompleted, setTradeCompleted] = useState(false);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const { refreshProfile } = useAuth();
  const [tradeDetails, setTradeDetails] = useState<{
    side: 'yes' | 'no';
    quantity: number;
    amount: number;
    partnerId?: string;
  } | null>(null);
  
  // Get trade details from the URL query parameters
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const side = searchParams.get('side') as 'yes' | 'no';
    const quantity = parseInt(searchParams.get('quantity') || '0');
    const amount = parseFloat(searchParams.get('amount') || '0');
    const partnerId = searchParams.get('partnerId') || undefined;
    
    if (side && quantity && amount) {
      setTradeDetails({ side, quantity, amount, partnerId });
    }
    
    // Simulate trade processing
    setTimeout(() => {
      setLoading(false);
      setTradeCompleted(true);
      
      // Call refreshProfile to update the user's balance
      refreshProfile();
      
      toast({
        title: "Trade successful",
        description: `Your ${side.toUpperCase()} order has been placed successfully`,
      });
    }, 1000);
  }, [location, toast, refreshProfile]);
  
  // Get event data
  const event = id ? events[id as keyof typeof events] : null;
  
  // Get trading partner data if partnerId is provided
  const partner = tradeDetails?.partnerId ? tradingPartners[tradeDetails.partnerId as keyof typeof tradingPartners] : null;
  
  if (!event || !tradeDetails) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Trade details not found</p>
      </div>
    );
  }
  
  const handleViewPortfolio = () => {
    navigate('/portfolio');
  };
  
  const handleExploreEvents = () => {
    navigate('/');
  };

  // Calculate potential winnings (simplified calculation)
  const potentialWinnings = tradeDetails.quantity * 10; // Example calculation
  
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white p-4 flex items-center justify-between shadow-sm">
        <Link to={`/event/${id}`} className="text-gray-700">
          <ArrowLeft size={22} />
        </Link>
        <h1 className="text-xl font-semibold">Trade Status</h1>
        <div className="w-6"></div> {/* Empty div for spacing */}
      </header>
      
      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4"
      >
        {loading ? (
          <div className="bg-white rounded-lg shadow-sm p-8 mb-4 flex flex-col items-center text-center">
            <div className="w-16 h-16 mb-4 flex items-center justify-center">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
            </div>
            <h2 className="text-xl font-semibold mb-2">Processing Your Trade</h2>
            <p className="text-gray-500">Please wait while we process your trade...</p>
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-sm p-8 mb-4 flex flex-col items-center text-center">
            <div className="w-16 h-16 mb-4 rounded-full bg-green-100 flex items-center justify-center">
              <CheckCircle className="w-10 h-10 text-green-500" />
            </div>
            <h2 className="text-xl font-semibold mb-2">Trade Successful!</h2>
            <p className="text-gray-500 mb-6">Your order has been placed successfully.</p>
            
            <div className="w-full bg-gray-50 rounded-lg p-4 mb-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-lg overflow-hidden">
                  <img src={event.image} alt={event.category} className="w-full h-full object-cover" />
                </div>
                <div className="text-left">
                  <h3 className="font-medium">{event.shortTitle}</h3>
                  <p className="text-sm text-gray-500">{event.title}</p>
                </div>
              </div>
              
              {partner && (
                <div className="mb-4 p-3 bg-blue-50 rounded-lg">
                  <div className="flex items-center mb-2">
                    <Handshake className="w-5 h-5 text-blue-500 mr-2" />
                    <p className="font-medium text-blue-700">Trade Match</p>
                  </div>
                  <div className="flex items-center">
                    <div className="flex items-center flex-1">
                      <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center mr-2">
                        <UserRound className="w-5 h-5 text-gray-500" />
                      </div>
                      <span className="font-medium">You</span>
                      <div className={`mx-2 px-2 py-0.5 rounded text-xs ${
                        tradeDetails.side === 'yes' ? 'bg-blue-100 text-blue-600' : 'bg-red-100 text-red-600'
                      }`}>
                        {tradeDetails.side.toUpperCase()}
                      </div>
                    </div>
                    <div className="flex-1 flex items-center">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center mr-2">
                        {partner.avatar ? (
                          <img src={partner.avatar} alt={partner.username} className="w-full h-full rounded-full object-cover" />
                        ) : (
                          <div className="w-full h-full rounded-full bg-blue-500 flex items-center justify-center">
                            <span className="text-white font-semibold">{partner.userInitial}</span>
                          </div>
                        )}
                      </div>
                      <span className="font-medium">{partner.username}</span>
                      <div className={`mx-2 px-2 py-0.5 rounded text-xs ${
                        partner.side === 'yes' ? 'bg-blue-100 text-blue-600' : 'bg-red-100 text-red-600'
                      }`}>
                        {partner.side.toUpperCase()}
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              <div className="grid grid-cols-2 gap-3 mb-3">
                <div className="text-left">
                  <p className="text-sm text-gray-500">Trade Type</p>
                  <p className="font-medium">
                    {tradeDetails.side === 'yes' ? (
                      <span className="text-blue-500">YES</span>
                    ) : (
                      <span className="text-red-500">NO</span>
                    )}
                  </p>
                </div>
                <div className="text-left">
                  <p className="text-sm text-gray-500">Quantity</p>
                  <p className="font-medium">{tradeDetails.quantity}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-3 mb-3">
                <div className="text-left">
                  <p className="text-sm text-gray-500">Amount Paid</p>
                  <p className="text-lg font-semibold flex items-center text-red-500">
                    <IndianRupee className="w-4 h-4 mr-1" />
                    {tradeDetails.amount.toFixed(2)}
                  </p>
                </div>
                <div className="text-left">
                  <p className="text-sm text-gray-500">Potential Winnings</p>
                  <p className="text-lg font-semibold flex items-center text-green-600">
                    <IndianRupee className="w-4 h-4 mr-1" />
                    {potentialWinnings.toFixed(2)}
                  </p>
                </div>
              </div>
            </div>
            
            <div className="flex gap-3 w-full">
              <button
                onClick={handleViewPortfolio}
                className="flex-1 py-3 rounded-lg bg-blue-500 text-white font-medium hover:bg-blue-600 transition-colors"
              >
                View Portfolio
              </button>
              <button
                onClick={handleExploreEvents}
                className="flex-1 py-3 rounded-lg border border-blue-500 text-blue-500 font-medium hover:bg-blue-50 transition-colors"
              >
                Explore Events
              </button>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default TradeExit;
