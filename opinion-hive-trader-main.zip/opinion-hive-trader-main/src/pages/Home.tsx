import React, { useState, useEffect } from 'react';
import { Search, Bell, Wallet, Grid3X3, Lightbulb } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import BottomNavigation from '@/components/BottomNavigation';
import { useAuth } from '@/hooks/useAuth';
import WinoxLogo from '@/components/WinoxLogo';
import Notifications from '@/components/Notifications';

// Mock data for events
const events = [
  {
    id: '1',
    category: 'Cricket',
    title: 'Mumbai Women to win the match vs Bengaluru Women?',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTZ7QJhG8ixIKfpfouVKAJHFvABGeNMSQKlzA&usqp=CAU',
    hint: 'H2H last 5 T20: Mumbai 3, Bengaluru 2, DRAW 0',
    yesPrice: '5.5',
    noPrice: '4.5',
    endTime: '11 Mar, 11:50 PM',
    traders: 414,
    volume: '₹20676',
  },
  {
    id: '2',
    category: 'Cricket',
    title: 'West Indies Masters to win the match vs South Africa Masters?',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYnZ-eFOr-LE8g2TfRgpHPLZG3jVvEj03j0g&usqp=CAU',
    yesPrice: '6.0',
    noPrice: '4.0',
    endTime: '12 Mar, 2:30 AM',
    traders: 211,
    volume: '₹12540',
  },
  {
    id: '3',
    category: 'Crypto',
    title: 'Bitcoin is forecasted to reach at 77655.25 USDT or more at 01:30 AM?',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRGIISxP2K_qgFRTc0-GQ6tHiUUmAwiO9BHrQ&usqp=CAU',
    hint: 'Price at 12:30 AM was 77655.25 USDT',
    yesPrice: '5.0',
    noPrice: '5.0',
    endTime: '11 Mar, 1:30 AM',
    traders: 190,
    volume: '₹9320',
  },
  {
    id: '4',
    category: 'Growth',
    title: 'Will India\'s GDP growth surpass 7.5% this quarter?',
    image: '/lovable-uploads/2a62c269-ad28-4d72-a043-ea9ba3881836.png',
    yesPrice: '7.2',
    noPrice: '2.8',
    endTime: '15 Mar, 6:00 PM',
    traders: 328,
    volume: '₹15420',
  },
];

// Category data
const categories = [
  { id: 'all', name: 'All', icon: '🎮' },
  { id: 'cricket', name: 'Cricket', icon: '🏏' },
  { id: 'football', name: 'Football', icon: '⚽' },
  { id: 'crypto', name: 'Crypto', icon: '₿' },
  { id: 'politics', name: 'Politics', icon: '🗣️' },
  { id: 'entertainment', name: 'Entertainment', icon: '🎬' },
];

// Trending events
const trendingEvents = [
  { id: '1', name: 'WI-M vs SA-M', icon: '🏏' },
  { id: '2', name: 'MUM-W vs BLR-W', icon: '🏏' },
  { id: '3', name: 'Growth', icon: '📈' },
  { id: '4', name: 'Politics', icon: '🗣️' },
  { id: '5', name: 'Crypto', icon: '₿' },
];

const Home = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [filteredEvents, setFilteredEvents] = useState(events);
  const { profile, user } = useAuth();
  
  useEffect(() => {
    if (selectedCategory === 'all') {
      setFilteredEvents(events);
    } else {
      setFilteredEvents(events.filter(event => 
        event.category.toLowerCase() === selectedCategory.toLowerCase()
      ));
    }
  }, [selectedCategory]);

  return (
    <div className="min-h-screen bg-gray-50 pb-16">
      {/* Header */}
      <header className="bg-white p-4 flex items-center justify-between shadow-sm">
        <WinoxLogo />
        
        <div className="flex items-center gap-3">
          <div className="bg-white rounded-full border border-gray-200 px-3 py-1 flex items-center">
            <Wallet className="h-4 w-4 text-gray-500 mr-2" />
            <span className="text-sm font-medium">₹{profile?.balance || 37.07}</span>
          </div>
          
          <Notifications />
          
          <Link to="/profile" className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
            <span className="text-sm font-medium text-blue-500">
              {profile?.username?.[0]?.toUpperCase() || (user?.email && user.email[0].toUpperCase()) || 'W'}
            </span>
          </Link>
        </div>
      </header>
      
      {/* Search Bar */}
      <div className="px-4 pt-4 pb-2">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
          <input
            type="text"
            placeholder="Explore events across categories"
            className="w-full bg-white border border-gray-200 rounded-full py-2.5 pl-10 pr-4 text-sm"
          />
        </div>
      </div>
      
      {/* Carousel */}
      <div className="px-4 py-2 overflow-hidden">
        <div className="relative">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="rounded-xl overflow-hidden h-36 bg-gradient-to-r from-green-800 to-green-600"
          >
            <img 
              src="/lovable-uploads/2a62c269-ad28-4d72-a043-ea9ba3881836.png" 
              alt="Will growth meet expectations?" 
              className="w-full h-full object-cover" 
            />
          </motion.div>
        </div>
      </div>
      
      {/* Trending Events */}
      <div className="px-4 pt-4">
        <h2 className="text-lg font-bold mb-3">Trending Events</h2>
        <div className="flex overflow-x-auto pb-2 gap-2 hide-scrollbar">
          {trendingEvents.map(event => (
            <Link 
              key={event.id}
              to={`/event/${event.id}`}
              className="flex-shrink-0 bg-white rounded-xl px-4 py-3 border border-gray-100 flex items-center gap-2"
            >
              <span className="text-xl">{event.icon}</span>
              <span className="whitespace-nowrap font-medium">{event.name}</span>
            </Link>
          ))}
        </div>
      </div>
      
      {/* Categories and Active Events */}
      <div className="px-4 pt-6">
        <h2 className="text-lg font-bold mb-3">Active Events</h2>
        
        <div className="flex overflow-x-auto pb-2 gap-2 hide-scrollbar">
          {categories.map(category => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`flex-shrink-0 px-4 py-2 rounded-full ${
                selectedCategory === category.id 
                ? 'bg-blue-500 text-white' 
                : 'bg-white text-gray-600 border border-gray-200'
              } flex items-center gap-2`}
            >
              <span>{category.icon}</span>
              <span className="whitespace-nowrap">{category.name}</span>
            </button>
          ))}
        </div>
        
        {/* Events List */}
        <div className="mt-4 space-y-4">
          {filteredEvents.map(event => (
            <Link key={event.id} to={`/event/${event.id}`} className="block">
              <div className="bg-white rounded-xl overflow-hidden shadow-sm p-4">
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0">
                    <img src={event.image} alt={event.category} className="w-full h-full object-cover" />
                  </div>
                  
                  <div className="flex-1">
                    <h3 className="font-medium text-gray-900 mb-1">{event.title}</h3>
                    
                    {event.hint && (
                      <div className="flex items-center gap-1 text-xs text-amber-600 mb-2">
                        <Lightbulb className="w-3 h-3 text-amber-500" />
                        <span>{event.hint}</span>
                      </div>
                    )}
                    
                    <div className="flex items-center text-xs text-gray-500 mb-2">
                      <span className="mr-2">Volume: {event.volume}</span>
                      <span>|</span>
                      <span className="mx-2">Traders: {event.traders}</span>
                      <span>|</span>
                      <span className="ml-2">Ends: {event.endTime}</span>
                    </div>
                    
                    <div className="flex gap-2 mt-2">
                      <button className="flex-1 py-2 rounded-lg bg-blue-50 text-blue-500 font-medium text-sm">
                        Yes ₹{event.yesPrice}
                      </button>
                      <button className="flex-1 py-2 rounded-lg bg-red-50 text-red-500 font-medium text-sm">
                        No ₹{event.noPrice}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
      
      <BottomNavigation activeTab="home" />
    </div>
  );
};

export default Home;
