
import React, { useState, useEffect } from 'react';
import { ArrowLeft, IndianRupee, AlertCircle } from 'lucide-react';
import { Link, useParams, useNavigate, useLocation } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { motion } from 'framer-motion';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';

// Mock event data
const events = {
  '1': {
    id: '1',
    title: 'Mumbai to win the match vs Bengaluru?',
    shortTitle: 'MUM vs BLR',
    category: 'Cricket',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTZ7QJhG8ixIKfpfouVKAJHFvABGeNMSQKlzA&usqp=CAU',
    yesPrice: 6.0,
    noPrice: 4.0,
    availableYes: 100,
    availableNo: 150,
    minAmount: 10,
    maxAmount: 1000,
  },
  '2': {
    id: '2',
    title: 'West Indies Masters to win the match vs South Africa Masters?',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYnZ-eFOr-LE8g2TfRgpHPLZG3jVvEj03j0g&usqp=CAU',
    shortTitle: 'WI-M vs SA-M',
    category: 'Cricket',
    yesPrice: 6.0,
    noPrice: 4.0,
    availableYes: 80,
    availableNo: 120,
    minAmount: 10,
    maxAmount: 1000,
  },
  '3': {
    id: '3',
    title: 'Bitcoin to reach 77655.25 USDT?',
    shortTitle: 'BTC Prediction',
    category: 'Crypto',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRGIISxP2K_qgFRTc0-GQ6tHiUUmAwiO9BHrQ&usqp=CAU',
    yesPrice: 5.0,
    noPrice: 5.0,
    availableYes: 200,
    availableNo: 200,
    minAmount: 10,
    maxAmount: 1000,
  },
  '4': {
    id: '4',
    title: 'India\'s GDP growth to surpass 7.5%?',
    shortTitle: 'GDP Growth',
    category: 'Economy',
    image: '/lovable-uploads/2a62c269-ad28-4d72-a043-ea9ba3881836.png',
    yesPrice: 7.2,
    noPrice: 2.8,
    availableYes: 150,
    availableNo: 250,
    minAmount: 10,
    maxAmount: 1000,
  }
};

const TradeMatch = () => {
  const { id } = useParams<{ id: string }>();
  const location = useLocation();
  const navigate = useNavigate();
  const [tradeType, setTradeType] = useState<'yes' | 'no'>('yes');
  const [quantity, setQuantity] = useState(1);
  const [amount, setAmount] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const { profile, refreshProfile } = useAuth();
  
  // Get trade side from the URL query parameters
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const side = searchParams.get('side');
    if (side === 'yes' || side === 'no') {
      setTradeType(side);
    }
  }, [location]);
  
  // Get event data
  const event = id ? events[id as keyof typeof events] : null;
  
  // Calculate amount whenever quantity or trade type changes
  useEffect(() => {
    if (event) {
      const price = tradeType === 'yes' ? event.yesPrice : event.noPrice;
      setAmount(price * quantity);
    }
  }, [quantity, tradeType, event]);
  
  // Handle quantity change
  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (!isNaN(value) && value >= 1) {
      if (event && value <= (tradeType === 'yes' ? event.availableYes : event.availableNo)) {
        setQuantity(value);
      }
    }
  };
  
  // Handle trade type switch
  const handleTradeTypeSwitch = (type: 'yes' | 'no') => {
    setTradeType(type);
    
    // Reset quantity if it exceeds available quantity of the new trade type
    if (event && quantity > (type === 'yes' ? event.availableYes : event.availableNo)) {
      setQuantity(1);
    }
  };
  
  // Handle trade execution
  const handleTrade = async () => {
    if (!event || !profile) return;
    
    if (amount > (profile?.balance || 0)) {
      toast({
        title: "Insufficient balance",
        description: "You don't have enough balance to place this trade",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsSubmitting(true);

      // Record the transaction in the database
      if (profile.id) {
        const { error: transactionError } = await supabase
          .from('transactions')
          .insert({
            user_id: profile.id,
            amount: amount,
            type: 'bet',
            status: 'completed',
            description: `${tradeType.toUpperCase()} bet on ${event.shortTitle}: ${event.title}`
          });

        if (transactionError) {
          throw new Error(transactionError.message);
        }

        // Update user balance
        const newBalance = (profile.balance || 0) - amount;
        const { error: profileError } = await supabase
          .from('profiles')
          .update({ balance: newBalance })
          .eq('id', profile.id);

        if (profileError) {
          throw new Error(profileError.message);
        }

        // Refresh user profile to get updated balance
        await refreshProfile();
      }

      // Navigate to trade exit page
      navigate(`/trade-exit/${id}?side=${tradeType}&quantity=${quantity}&amount=${amount}`);
    } catch (error) {
      console.error('Error placing trade:', error);
      toast({
        title: "Error placing trade",
        description: error instanceof Error ? error.message : "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  if (!event) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Event not found</p>
      </div>
    );
  }

  // Calculate potential winnings (simplified calculation)
  const potentialWinnings = quantity * 10; // Example calculation
  
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white p-4 flex items-center justify-between shadow-sm">
        <Link to={`/event/${id}`} className="text-gray-700">
          <ArrowLeft size={22} />
        </Link>
        <h1 className="text-xl font-semibold">Trade</h1>
        <div className="w-6"></div> {/* Empty div for spacing */}
      </header>
      
      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4"
      >
        <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-lg overflow-hidden">
              <img src={event.image} alt={event.category} className="w-full h-full object-cover" />
            </div>
            <div>
              <h3 className="font-medium">{event.shortTitle}</h3>
              <p className="text-sm text-gray-500">{event.title}</p>
            </div>
          </div>
          
          <div className="bg-gray-50 p-3 rounded-lg mb-4">
            <p className="font-medium">Your Balance</p>
            <p className="text-xl font-semibold">₹{profile?.balance?.toFixed(2) || 0}</p>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
          <h2 className="text-lg font-semibold mb-4">Trade Type</h2>
          
          <div className="grid grid-cols-2 gap-3 mb-6">
            <button
              onClick={() => handleTradeTypeSwitch('yes')}
              className={`py-3 rounded-lg font-medium ${
                tradeType === 'yes' 
                  ? 'bg-blue-500 text-white' 
                  : 'bg-blue-50 text-blue-500'
              }`}
            >
              Yes ₹{event.yesPrice.toFixed(1)}
            </button>
            <button
              onClick={() => handleTradeTypeSwitch('no')}
              className={`py-3 rounded-lg font-medium ${
                tradeType === 'no' 
                  ? 'bg-red-500 text-white' 
                  : 'bg-red-50 text-red-500'
              }`}
            >
              No ₹{event.noPrice.toFixed(1)}
            </button>
          </div>
          
          <div className="mb-6">
            <div className="flex justify-between mb-2">
              <label className="font-medium">Quantity</label>
              <span className="text-sm text-gray-500">
                Available: {tradeType === 'yes' ? event.availableYes : event.availableNo}
              </span>
            </div>
            
            <div className="flex items-center border border-gray-300 rounded-lg overflow-hidden">
              <button
                onClick={() => quantity > 1 && setQuantity(quantity - 1)}
                className="w-12 h-12 flex items-center justify-center text-gray-500 hover:bg-gray-100"
                type="button"
              >
                -
              </button>
              <input
                type="number"
                value={quantity}
                onChange={handleQuantityChange}
                min="1"
                max={tradeType === 'yes' ? event.availableYes : event.availableNo}
                className="flex-1 h-12 text-center outline-none"
              />
              <button
                onClick={() => quantity < (tradeType === 'yes' ? event.availableYes : event.availableNo) && setQuantity(quantity + 1)}
                className="w-12 h-12 flex items-center justify-center text-gray-500 hover:bg-gray-100"
                type="button"
              >
                +
              </button>
            </div>
          </div>
          
          <div className="mb-6">
            <label className="font-medium block mb-2">Total Amount</label>
            <div className="flex items-center border border-gray-300 rounded-lg p-3">
              <IndianRupee className="text-gray-400 mr-2" size={20} />
              <input
                type="text"
                value={amount.toFixed(2)}
                readOnly
                className="flex-1 outline-none text-lg"
              />
            </div>
          </div>

          <div className="mb-6">
            <label className="font-medium block mb-2">Potential Winnings</label>
            <div className="flex items-center border border-green-100 bg-green-50 rounded-lg p-3">
              <IndianRupee className="text-green-600 mr-2" size={20} />
              <input
                type="text"
                value={potentialWinnings.toFixed(2)}
                readOnly
                className="flex-1 outline-none text-lg bg-transparent text-green-600 font-semibold"
              />
            </div>
          </div>
          
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mb-6 flex items-start">
            <AlertCircle className="text-amber-500 mr-2 flex-shrink-0 mt-0.5" size={18} />
            <p className="text-sm text-amber-700">
              {tradeType === 'yes' 
                ? `If the outcome is YES, you'll win ₹${potentialWinnings.toFixed(2)}. If it's NO, you'll lose your stake.`
                : `If the outcome is NO, you'll win ₹${potentialWinnings.toFixed(2)}. If it's YES, you'll lose your stake.`}
            </p>
          </div>
        </div>
        
        <button
          onClick={handleTrade}
          disabled={quantity < 1 || amount > (profile?.balance || 0) || isSubmitting}
          className={`w-full rounded-lg py-3 text-white font-medium mb-4 relative ${
            quantity < 1 || amount > (profile?.balance || 0) || isSubmitting
              ? 'bg-gray-400' 
              : tradeType === 'yes' ? 'bg-blue-500 hover:bg-blue-600' : 'bg-red-500 hover:bg-red-600'
          }`}
        >
          {isSubmitting ? (
            <>
              <span className="opacity-0">Place {tradeType.toUpperCase()} Order</span>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              </div>
            </>
          ) : (
            `Place ${tradeType.toUpperCase()} Order`
          )}
        </button>
      </motion.div>
    </div>
  );
};

export default TradeMatch;
