
import React, { useState } from 'react';
import { ArrowLeft, ArrowDownToLine, IndianRupee, Building, AlertCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { motion } from 'framer-motion';
import BottomNavigation from '@/components/BottomNavigation';
import { useAuth } from '@/hooks/useAuth';

const predefinedAmounts = [100, 200, 500, 1000];

const Withdrawal = () => {
  const [amount, setAmount] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [webhookUrl, setWebhookUrl] = useState('');
  const { toast } = useToast();
  const { profile, refreshProfile } = useAuth();
  
  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    // Only allow numbers
    if (/^\d*$/.test(value)) {
      setAmount(value);
    }
  };
  
  const handleSelectAmount = (value: number) => {
    setAmount(value.toString());
  };
  
  const handleWithdraw = async () => {
    const numAmount = parseInt(amount);
    const balance = profile?.balance || 0;
    
    if (!amount || numAmount < 100) {
      toast({
        title: "Invalid amount",
        description: "Amount should be at least ₹100",
        variant: "destructive",
      });
      return;
    }
    
    if (numAmount > balance) {
      toast({
        title: "Insufficient balance",
        description: "You don't have enough balance for this withdrawal",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Trigger webhook if URL is provided
      if (webhookUrl) {
        await fetch(webhookUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          mode: 'no-cors',
          body: JSON.stringify({
            type: 'withdrawal',
            userId: profile?.id,
            amount: numAmount,
            timestamp: new Date().toISOString()
          }),
        });
        console.log('Withdrawal webhook triggered');
      }
      
      // Simulate withdrawal processing
      setTimeout(() => {
        setIsLoading(false);
        toast({
          title: "Withdrawal initiated",
          description: `₹${amount} will be credited to your bank account within 24 hours`,
        });
        
        // Refresh user profile to get updated balance
        refreshProfile();
        
        // Reset form
        setAmount('');
      }, 2000);
    } catch (error) {
      console.error('Withdrawal error:', error);
      setIsLoading(false);
      toast({
        title: "Withdrawal failed",
        description: "An error occurred during the withdrawal process",
        variant: "destructive",
      });
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-50 pb-16">
      <header className="bg-white p-4 flex items-center justify-between shadow-sm">
        <Link to="/profile" className="text-gray-700">
          <ArrowLeft size={22} />
        </Link>
        <h1 className="text-xl font-semibold">Withdraw Money</h1>
        <div className="w-6"></div> {/* Empty div for spacing */}
      </header>
      
      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4"
      >
        <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">Available Balance</h2>
            <span className="font-bold text-xl">₹{profile?.balance || 0}</span>
          </div>
          
          <div className="border-t border-gray-100 pt-4">
            <h2 className="text-lg font-semibold mb-4">Enter Withdrawal Amount</h2>
            
            <div className="flex items-center border border-gray-300 rounded-lg p-3 mb-4">
              <IndianRupee className="text-gray-400 mr-2" size={20} />
              <input
                type="text"
                value={amount}
                onChange={handleAmountChange}
                placeholder="Enter amount"
                className="flex-1 outline-none text-lg"
              />
            </div>
            
            <div className="flex flex-wrap gap-2 mb-6">
              {predefinedAmounts.map(value => (
                <button
                  key={value}
                  onClick={() => handleSelectAmount(value)}
                  className={`px-4 py-2 rounded-md border ${
                    amount === value.toString() 
                      ? 'bg-blue-50 border-blue-500 text-blue-500' 
                      : 'border-gray-300 text-gray-700'
                  }`}
                >
                  ₹{value}
                </button>
              ))}
            </div>
            
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mb-6 flex items-start">
              <AlertCircle className="text-amber-500 mr-2 flex-shrink-0 mt-0.5" size={18} />
              <p className="text-sm text-amber-700">
                Minimum withdrawal amount is ₹100. Processing time is 24 hours.
              </p>
            </div>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Webhook URL (Optional)
              </label>
              <input
                type="text"
                value={webhookUrl}
                onChange={(e) => setWebhookUrl(e.target.value)}
                placeholder="Enter webhook URL for notifications"
                className="w-full p-3 border border-gray-300 rounded-lg"
              />
              <p className="text-xs text-gray-500 mt-1">
                Add a webhook URL to receive notifications when withdrawals are processed.
              </p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
          <h2 className="text-lg font-semibold mb-4">Bank Account</h2>
          
          <div className="p-4 border rounded-lg flex items-center border-blue-500 bg-blue-50">
            <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
              <Building className="text-blue-600" size={20} />
            </div>
            <div>
              <h3 className="font-medium">HDFC Bank</h3>
              <p className="text-sm text-gray-500">Account ending with ****1234</p>
            </div>
          </div>
        </div>
        
        <button
          onClick={handleWithdraw}
          disabled={isLoading || !amount}
          className={`w-full rounded-lg py-3 text-white font-medium mb-4 flex items-center justify-center gap-2 ${
            isLoading || !amount 
              ? 'bg-gray-400' 
              : 'bg-blue-500'
          }`}
        >
          <ArrowDownToLine size={18} />
          {isLoading ? 'Processing...' : `Withdraw ₹${amount || '0'}`}
        </button>
      </motion.div>
      
      <BottomNavigation activeTab="profile" />
    </div>
  );
};

export default Withdrawal;
