
import React from 'react';
import { ArrowLeft, LogOut, Shield, Bell, Moon, HelpCircle } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import BottomNavigation from '@/components/BottomNavigation';

const Settings = () => {
  const { signOut } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleLogout = async () => {
    try {
      await signOut();
      toast({
        title: "Logged out",
        description: "You have been successfully logged out",
      });
      navigate('/auth');
    } catch (error) {
      console.error("Logout error:", error);
      toast({
        title: "Error",
        description: "Could not log out. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-16">
      <header className="bg-white p-4 flex items-center justify-between shadow-sm">
        <Link to="/profile" className="text-gray-700">
          <ArrowLeft size={22} />
        </Link>
        <h1 className="text-xl font-semibold">Settings</h1>
        <div className="w-5"></div>
      </header>
      
      <div className="bg-white divide-y divide-gray-100 mt-4">
        <Link to="/profile-edit" className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-3">
              <Shield className="w-4 h-4 text-blue-600" />
            </div>
            <span>Privacy & Security</span>
          </div>
        </Link>
        
        <Link to="/notifications-settings" className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center mr-3">
              <Bell className="w-4 h-4 text-amber-600" />
            </div>
            <span>Notifications</span>
          </div>
        </Link>
        
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center mr-3">
              <Moon className="w-4 h-4 text-indigo-600" />
            </div>
            <span>Dark Mode</span>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input type="checkbox" value="" className="sr-only peer" />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
          </label>
        </div>
        
        <Link to="/help" className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-3">
              <HelpCircle className="w-4 h-4 text-green-600" />
            </div>
            <span>Help & Support</span>
          </div>
        </Link>
        
        <button 
          onClick={handleLogout}
          className="flex items-center text-red-500 p-4 w-full"
        >
          <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center mr-3">
            <LogOut className="w-4 h-4 text-red-600" />
          </div>
          <span>Log Out</span>
        </button>
      </div>
      
      <div className="text-center mt-8 text-sm text-gray-500">
        <p>Winox Trading App</p>
        <p className="mt-1">Version 1.0.0</p>
      </div>
      
      <BottomNavigation activeTab="profile" />
    </div>
  );
};

export default Settings;
