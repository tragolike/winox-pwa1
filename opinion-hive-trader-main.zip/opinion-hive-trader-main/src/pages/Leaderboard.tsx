
import React, { useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import BottomNavigation from '@/components/BottomNavigation';

// Mock data for leaderboard
const leaderboardUsers = [
  {
    id: '1',
    name: 'tinkukumar293',
    amount: 355716.68,
    position: 1,
  },
  {
    id: '2',
    name: 'govind9628',
    amount: 173592.46,
    position: 2,
  },
  {
    id: '3',
    name: 'roshanpal328',
    amount: 148003.97,
    position: 3,
  },
  {
    id: '4',
    name: 'crispy697',
    avatar: '/lovable-uploads/315aa59c-a137-4eab-a266-b6a7e154e26f.png',
    amount: 124891.34,
    position: 4,
  },
  {
    id: '5',
    name: 'crixp106',
    avatar: '/lovable-uploads/315d0e99-d92d-4acc-af2c-716e30f049b5.png',
    amount: 95688.82,
    position: 5,
  },
  {
    id: '6',
    name: 'vishalsingh151',
    avatar: '/lovable-uploads/bb61ce5c-e314-4d63-a09b-e0b0db1281b1.png',
    amount: 86898.02,
    position: 6,
  },
  {
    id: '7',
    name: 'khushboosing985',
    avatar: '/lovable-uploads/a840746c-9441-4453-8dec-9dc3e4fee2fb.png',
    amount: 77105.58,
    position: 7,
  },
  {
    id: '8',
    name: 'mahkal202',
    amount: 74677.74,
    position: 8,
  },
  {
    id: '42',
    name: 'suraj112',
    avatar: '/lovable-uploads/568d9019-5fed-4032-98b7-b526b5b21024.png',
    amount: 33.57,
    position: 4563,
    isCurrentUser: true,
  },
];

const Leaderboard = () => {
  const [selectedTab, setSelectedTab] = useState<'winnings' | 'investment'>('winnings');

  const handleTabChange = (tab: 'winnings' | 'investment') => {
    setSelectedTab(tab);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="flex items-center justify-between p-4 bg-white shadow-sm">
        <Link to="/" className="text-gray-700">
          <ArrowLeft size={24} />
        </Link>
        <h1 className="text-xl font-semibold">Leaderboard</h1>
        <div className="w-6"></div> {/* Empty div for spacing */}
      </header>

      {/* Tab selector */}
      <div className="flex w-full bg-white border-b border-gray-200">
        <button
          className={`flex-1 py-3 text-center font-medium text-lg ${
            selectedTab === 'winnings' 
              ? 'text-black border-b-2 border-black' 
              : 'text-gray-400'
          }`}
          onClick={() => handleTabChange('winnings')}
        >
          Winnings
        </button>
        <button
          className={`flex-1 py-3 text-center font-medium text-lg ${
            selectedTab === 'investment' 
              ? 'text-black border-b-2 border-black' 
              : 'text-gray-400'
          }`}
          onClick={() => handleTabChange('investment')}
        >
          Investment
        </button>
      </div>

      {/* Top 3 winners */}
      <div className="p-6 bg-blue-50">
        <div className="flex justify-around items-end">
          {/* 2nd place */}
          <div className="flex flex-col items-center">
            <div className="w-20 h-20 flex items-center justify-center">
              <img 
                src="/lovable-uploads/23fbfcf6-809f-401c-bdf8-13636efcd943.png" 
                alt="Silver medal" 
                className="w-full h-full object-contain"
              />
            </div>
            <p className="mt-1 text-gray-800">{leaderboardUsers[1].name}</p>
            <p className="font-semibold text-gray-900">₹ {leaderboardUsers[1].amount.toLocaleString()}</p>
          </div>

          {/* 1st place */}
          <div className="flex flex-col items-center mb-4">
            <div className="w-24 h-24 flex items-center justify-center">
              <img 
                src="/lovable-uploads/04702312-c9e8-4ec8-bec2-1d75a5830ef2.png" 
                alt="Gold medal" 
                className="w-full h-full object-contain" 
              />
            </div>
            <p className="mt-1 text-gray-800">{leaderboardUsers[0].name}</p>
            <p className="font-semibold text-gray-900">₹ {leaderboardUsers[0].amount.toLocaleString()}</p>
          </div>

          {/* 3rd place */}
          <div className="flex flex-col items-center">
            <div className="w-20 h-20 flex items-center justify-center">
              <img 
                src="/lovable-uploads/1594af1e-a2de-4c82-bb53-ae22e7a7ac93.png" 
                alt="Bronze medal" 
                className="w-full h-full object-contain"
              />
            </div>
            <p className="mt-1 text-gray-800">{leaderboardUsers[2].name}</p>
            <p className="font-semibold text-gray-900">₹ {leaderboardUsers[2].amount.toLocaleString()}</p>
          </div>
        </div>
      </div>

      {/* Leaderboard list */}
      <div className="bg-white mb-20">
        {leaderboardUsers.slice(3).map((user) => (
          <motion.div 
            key={user.id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
            className={`flex items-center p-4 border-b border-gray-100 ${
              user.isCurrentUser ? 'bg-blue-50' : ''
            }`}
          >
            <div className="w-12 h-12 overflow-hidden rounded-full bg-blue-100 flex items-center justify-center">
              {user.avatar ? (
                <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
              ) : (
                <span className="text-blue-500 text-lg font-medium">{user.name.charAt(0).toUpperCase()}</span>
              )}
            </div>
            <div className="ml-3 flex-1">
              <p className="font-medium">
                {user.name}
                {user.isCurrentUser && <span className="text-blue-500 ml-1">(You)</span>}
              </p>
              <p className="text-gray-600">₹ {user.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
            </div>
            <div className="font-semibold text-gray-700">
              #{user.position}
            </div>
          </motion.div>
        ))}
      </div>

      <BottomNavigation activeTab="leaderboard" />
    </div>
  );
};

export default Leaderboard;
