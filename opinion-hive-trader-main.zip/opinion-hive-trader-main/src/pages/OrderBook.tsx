
import React from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, Clock, Handshake } from 'lucide-react';
import BottomNavigation from '@/components/BottomNavigation';

// Mock order book data
const orders = [
  { 
    id: '1', 
    user: 'paapiaadmi918', 
    yesPrice: '₹5.5', 
    noPrice: '₹4.5', 
    quantity: 3,
    timestamp: '2 minutes ago',
    side: 'yes',
    matchedWith: {
      user: 'amitkumaryad',
      userInitial: 'A',
      side: 'no'
    }
  },
  { 
    id: '2', 
    user: 'arishadbhat161', 
    yesPrice: '₹6', 
    noPrice: '₹4', 
    quantity: 2,
    timestamp: '5 minutes ago',
    side: 'yes',
    matchedWith: {
      user: 'tinkukumar293',
      userInitial: 'T',
      side: 'no'
    }
  },
  { 
    id: '3', 
    user: 'rupeshkumar435', 
    yesPrice: '₹8', 
    noPrice: '₹2', 
    quantity: 1,
    timestamp: '10 minutes ago',
    side: 'yes'
  },
  { 
    id: '4', 
    user: 'tinkukumar293', 
    yesPrice: '₹6', 
    noPrice: '₹4', 
    quantity: 5,
    timestamp: '15 minutes ago',
    side: 'no'
  },
  { 
    id: '5', 
    user: 'amitkumaryad', 
    yesPrice: '₹5', 
    noPrice: '₹5', 
    quantity: 3,
    timestamp: '20 minutes ago',
    side: 'no'
  },
];

const OrderBook = () => {
  const { id } = useParams<{ id: string }>();
  
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white p-4 flex items-center justify-between shadow-sm">
        <Link to={`/event/${id}`} className="text-gray-700">
          <ArrowLeft size={22} />
        </Link>
        <h1 className="text-lg font-semibold">Order Book</h1>
        <div className="w-5"></div> {/* Empty space for alignment */}
      </header>
      
      <div className="p-4">
        <div className="bg-white rounded-lg shadow-sm">
          <div className="p-4 border-b border-gray-100">
            <h2 className="font-semibold text-gray-700">Active Orders</h2>
          </div>
          
          <div className="divide-y divide-gray-100">
            {orders.map(order => (
              <div key={order.id} className="p-4">
                {order.matchedWith ? (
                  <div className="mb-3 p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-center mb-2">
                      <Handshake className="w-4 h-4 text-blue-500 mr-1" />
                      <p className="text-sm font-medium text-blue-700">Trade Match</p>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          order.side === 'yes' ? 'bg-blue-500' : 'bg-red-500'
                        }`}>
                          <span className="text-white font-medium">{order.user.charAt(0).toUpperCase()}</span>
                        </div>
                        <span className="ml-2 text-sm font-medium">{order.user}</span>
                        <span className={`ml-2 text-xs px-2 py-0.5 rounded-full ${
                          order.side === 'yes' ? 'bg-blue-100 text-blue-600' : 'bg-red-100 text-red-600'
                        }`}>
                          {order.side.toUpperCase()}
                        </span>
                      </div>
                      
                      <div className="text-center text-gray-400">
                        <span className="text-xs">matched with</span>
                      </div>
                      
                      <div className="flex items-center">
                        <span className={`mr-2 text-xs px-2 py-0.5 rounded-full ${
                          order.matchedWith.side === 'yes' ? 'bg-blue-100 text-blue-600' : 'bg-red-100 text-red-600'
                        }`}>
                          {order.matchedWith.side.toUpperCase()}
                        </span>
                        <span className="mr-2 text-sm font-medium">{order.matchedWith.user}</span>
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          order.matchedWith.side === 'yes' ? 'bg-blue-500' : 'bg-red-500'
                        }`}>
                          <span className="text-white font-medium">{order.matchedWith.userInitial}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : null}
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className={`w-10 h-10 rounded-full mr-3 flex items-center justify-center ${
                      order.side === 'yes' ? 'bg-blue-100 text-blue-500' : 'bg-red-100 text-red-500'
                    }`}>
                      {order.user.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p className="font-medium">{order.user}</p>
                      <div className="flex items-center text-sm text-gray-500">
                        <Clock className="w-3 h-3 mr-1" />
                        <span>{order.timestamp}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`text-sm px-2 py-0.5 rounded ${
                        order.side === 'yes' ? 'bg-blue-50 text-blue-500' : 'bg-red-50 text-red-500'
                      }`}>
                        {order.side === 'yes' ? 'YES' : 'NO'}
                      </span>
                      <span className="text-sm bg-gray-100 px-2 py-0.5 rounded">
                        {order.side === 'yes' ? order.yesPrice : order.noPrice}
                      </span>
                    </div>
                    <p className="text-sm">Qty: <span className="font-medium">{order.quantity}</span></p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      <BottomNavigation activeTab="home" />
    </div>
  );
};

export default OrderBook;
