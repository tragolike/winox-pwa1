
import React from 'react';
import { ArrowLeft, TrendingUp, TrendingDown } from 'lucide-react';
import { Link } from 'react-router-dom';
import BottomNavigation from '@/components/BottomNavigation';
import { useAuth } from '@/hooks/useAuth';

// Mock portfolio data
const portfolioItems = [
  {
    id: '1',
    title: 'Mumbai Women to win the match vs Bengaluru Women?',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTZ7QJhG8ixIKfpfouVKAJHFvABGeNMSQKlzA&usqp=CAU',
    invested: 25.5,
    currentValue: 30.0,
    profitPercent: 17.6,
    isProfit: true,
    endTime: '11 Mar, 11:50 PM',
  },
  {
    id: '2',
    title: 'West Indies Masters to win the match vs South Africa Masters?',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYnZ-eFOr-LE8g2TfRgpHPLZG3jVvEj03j0g&usqp=CAU',
    invested: 18.0,
    currentValue: 16.2,
    profitPercent: 10.0,
    isProfit: false,
    endTime: '12 Mar, 2:30 AM',
  },
];

const Portfolio = () => {
  const { profile } = useAuth();
  
  return (
    <div className="min-h-screen bg-gray-50 pb-16">
      <header className="bg-white p-4 flex items-center justify-between shadow-sm">
        <Link to="/" className="text-gray-700">
          <ArrowLeft size={22} />
        </Link>
        <h1 className="text-xl font-semibold">My Portfolio</h1>
        <div className="w-6"></div> {/* Empty div for spacing */}
      </header>
      
      {/* Portfolio Summary */}
      <div className="bg-white p-4 mb-4">
        <div className="mb-4">
          <h2 className="text-gray-500 text-sm">Total Value</h2>
          <p className="text-2xl font-bold">₹{(profile?.balance || 37.07) + 46.2}</p>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-gray-50 rounded-lg p-3">
            <h3 className="text-gray-500 text-sm">Available Balance</h3>
            <p className="text-lg font-semibold">₹{profile?.balance || 37.07}</p>
          </div>
          
          <div className="bg-gray-50 rounded-lg p-3">
            <h3 className="text-gray-500 text-sm">Invested</h3>
            <p className="text-lg font-semibold">₹46.20</p>
          </div>
        </div>
      </div>
      
      {/* Open Positions */}
      <div className="bg-white mb-4">
        <div className="p-4 border-b border-gray-100">
          <h2 className="font-semibold">Open Positions</h2>
        </div>
        
        <div className="divide-y divide-gray-100">
          {portfolioItems.map(item => (
            <Link key={item.id} to={`/event/${item.id}`} className="block p-4">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0">
                  <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
                </div>
                
                <div className="flex-1">
                  <h3 className="font-medium text-gray-900 mb-1 line-clamp-2">{item.title}</h3>
                  
                  <div className="flex items-center justify-between mt-2">
                    <div>
                      <p className="text-xs text-gray-500">Invested</p>
                      <p className="font-medium">₹{item.invested.toFixed(2)}</p>
                    </div>
                    
                    <div>
                      <p className="text-xs text-gray-500">Current Value</p>
                      <p className="font-medium">₹{item.currentValue.toFixed(2)}</p>
                    </div>
                    
                    <div className={`flex items-center ${
                      item.isProfit ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {item.isProfit ? (
                        <TrendingUp className="w-4 h-4 mr-1" />
                      ) : (
                        <TrendingDown className="w-4 h-4 mr-1" />
                      )}
                      <span className="font-medium">{item.profitPercent}%</span>
                    </div>
                  </div>
                  
                  <div className="mt-1 text-xs text-gray-500">
                    Expires: {item.endTime}
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
      
      {/* Completed Trades */}
      <div className="bg-white">
        <div className="p-4 border-b border-gray-100">
          <h2 className="font-semibold">Completed Trades</h2>
        </div>
        
        <div className="p-8 text-center text-gray-500">
          <p>No completed trades yet</p>
        </div>
      </div>
      
      <BottomNavigation activeTab="portfolio" />
    </div>
  );
};

export default Portfolio;
