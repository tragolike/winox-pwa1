
import React from 'react';
import { ArrowLeft, LogOut, User, Wallet, Settings, Copy, ChevronRight, IndianRupee, ArrowDownToLine } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import BottomNavigation from '@/components/BottomNavigation';

const Profile = () => {
  const { user, profile, signOut } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleLogout = async () => {
    try {
      await signOut();
      toast({
        title: "Logged out",
        description: "You have been successfully logged out",
      });
      navigate('/auth');
    } catch (error) {
      console.error("Logout error:", error);
      toast({
        title: "Error",
        description: "Could not log out. Please try again.",
        variant: "destructive",
      });
    }
  };

  const copyReferralCode = () => {
    navigator.clipboard.writeText('WINOX123');
    toast({
      title: "Copied!",
      description: "Referral code copied to clipboard",
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-16">
      <header className="bg-white p-4 flex items-center justify-between shadow-sm">
        <Link to="/" className="text-gray-700">
          <ArrowLeft size={22} />
        </Link>
        <h1 className="text-xl font-semibold">My Profile</h1>
        <button onClick={handleLogout} className="text-red-500">
          <LogOut size={20} />
        </button>
      </header>
      
      {/* Profile Overview */}
      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white p-4 mb-4"
      >
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center">
            {profile?.avatar_url ? (
              <img src={profile.avatar_url} alt="Profile" className="w-full h-full rounded-full object-cover" />
            ) : (
              <span className="text-2xl font-semibold text-blue-500">
                {profile?.username?.[0]?.toUpperCase() || (user?.email && user.email[0].toUpperCase()) || 'W'}
              </span>
            )}
          </div>
          
          <div>
            <h2 className="text-xl font-semibold">{profile?.username || (user?.email?.split('@')[0]) || 'User'}</h2>
            <p className="text-gray-500">{user?.email || 'No email'}</p>
          </div>
        </div>
        
        <div className="flex justify-between items-center mt-4 p-3 bg-gray-50 rounded-lg">
          <div>
            <p className="text-gray-500 text-sm">Wallet Balance</p>
            <p className="text-lg font-semibold">₹{profile?.balance || 0}</p>
          </div>
          
          <div className="flex gap-2">
            <Link
              to="/withdrawal"
              className="px-3 py-2 border border-gray-300 text-gray-700 rounded-lg font-medium text-sm flex items-center"
            >
              <ArrowDownToLine size={16} className="mr-1" />
              Withdraw
            </Link>
            <Link
              to="/cash"
              className="px-3 py-2 bg-blue-500 text-white rounded-lg font-medium text-sm flex items-center"
            >
              <IndianRupee size={16} className="mr-1" />
              Add Money
            </Link>
          </div>
        </div>
      </motion.div>
      
      {/* Statistics */}
      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white p-4 mb-4"
      >
        <h3 className="font-semibold mb-3">Statistics</h3>
        
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-gray-50 p-3 rounded-lg text-center">
            <p className="font-semibold text-lg">68%</p>
            <p className="text-xs text-gray-500">Winning Rate</p>
          </div>
          
          <div className="bg-gray-50 p-3 rounded-lg text-center">
            <p className="font-semibold text-lg">12</p>
            <p className="text-xs text-gray-500">Total Trades</p>
          </div>
          
          <div className="bg-gray-50 p-3 rounded-lg text-center">
            <p className="font-semibold text-lg">3</p>
            <p className="text-xs text-gray-500">Active Trades</p>
          </div>
        </div>
      </motion.div>
      
      {/* Referral */}
      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white p-4 mb-4"
      >
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 p-4 rounded-lg text-white">
          <h3 className="font-semibold mb-2">Refer & Earn</h3>
          <p className="text-sm text-blue-100 mb-3">Invite friends and earn ₹50 for each successful referral</p>
          
          <div className="flex items-center bg-white/20 rounded-lg p-2 backdrop-blur-sm">
            <span className="text-sm font-medium flex-1">WINOX123</span>
            <button 
              onClick={copyReferralCode}
              className="p-1.5 bg-white rounded text-blue-600"
            >
              <Copy size={16} />
            </button>
          </div>
        </div>
      </motion.div>
      
      {/* Menu Options */}
      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-white divide-y divide-gray-100"
      >
        <Link to="/profile-edit" className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-3">
              <User className="w-4 h-4 text-blue-600" />
            </div>
            <span>Edit Profile</span>
          </div>
          <ChevronRight size={18} className="text-gray-400" />
        </Link>
        
        <Link to="/cash" className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-3">
              <IndianRupee className="w-4 h-4 text-green-600" />
            </div>
            <span>Add Money</span>
          </div>
          <ChevronRight size={18} className="text-gray-400" />
        </Link>
        
        <Link to="/withdrawal" className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center mr-3">
              <ArrowDownToLine className="w-4 h-4 text-red-600" />
            </div>
            <span>Withdraw Money</span>
          </div>
          <ChevronRight size={18} className="text-gray-400" />
        </Link>
        
        <Link to="/settings" className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center mr-3">
              <Settings className="w-4 h-4 text-gray-600" />
            </div>
            <span>Settings</span>
          </div>
          <ChevronRight size={18} className="text-gray-400" />
        </Link>
      </motion.div>
      
      <BottomNavigation activeTab="profile" />
    </div>
  );
};

export default Profile;
