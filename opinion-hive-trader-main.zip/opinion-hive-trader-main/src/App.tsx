
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import Home from "./pages/Home";
import NotFound from "./pages/NotFound";
import Auth from "./pages/Auth";
import EventDetail from "./pages/EventDetail";
import Leaderboard from "./pages/Leaderboard";
import OrderBook from "./pages/OrderBook";
import Portfolio from "./pages/Portfolio";
import Profile from "./pages/Profile";
import Cash from "./pages/Cash";
import Withdrawal from "./pages/Withdrawal";
import TradeMatch from "./pages/TradeMatch";
import TradeExit from "./pages/TradeExit";
import Search from "./pages/Search";
import Settings from "./pages/Settings";
import Admin from "./pages/Admin";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/event/:id" element={<EventDetail />} />
            <Route path="/leaderboard" element={<Leaderboard />} />
            <Route path="/order-book/:id" element={<OrderBook />} />
            <Route path="/portfolio" element={<Portfolio />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/cash" element={<Cash />} />
            <Route path="/withdrawal" element={<Withdrawal />} />
            <Route path="/trade-match/:id" element={<TradeMatch />} />
            <Route path="/trade-exit/:id" element={<TradeExit />} />
            <Route path="/search" element={<Search />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/admin" element={<Admin />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
