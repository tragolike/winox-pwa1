
import React from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';

interface DataPoint {
  time: string;
  probability: number;
}

interface ProbabilityChartProps {
  data: DataPoint[];
  timeRange: '1h' | '6h' | '12h' | 'all';
  setTimeRange: (range: '1h' | '6h' | '12h' | 'all') => void;
  choice: 'yes' | 'no';
  probability: number;
  change: number;
}

const ProbabilityChart: React.FC<ProbabilityChartProps> = ({
  data,
  timeRange,
  setTimeRange,
  choice,
  probability,
  change,
}) => {
  return (
    <div className="bg-white rounded-xl border border-border shadow-sm overflow-hidden p-4">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="flex items-center">
            <div className={`mr-2 w-6 h-6 rounded-full flex items-center justify-center ${choice === 'yes' ? 'bg-yes-light' : 'bg-no-light'}`}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path 
                  d="M7 14l5-5 5 5" 
                  stroke={choice === 'yes' ? '#2b82ea' : '#f87171'} 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                />
              </svg>
            </div>
            <span className="font-medium">
              {choice.toUpperCase()}
            </span>
          </div>
          <div className="flex items-baseline mt-1">
            <span className="text-2xl font-bold">{probability}% Probability</span>
            <span className={`ml-2 text-sm ${change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {change >= 0 ? '+' : ''}{change}%
            </span>
          </div>
        </div>
        
        <div className="flex items-center space-x-1 bg-muted/50 rounded-lg p-1">
          {(['1h', '6h', '12h', 'all'] as const).map((range) => (
            <button
              key={range}
              onClick={() => setTimeRange(range)}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                timeRange === range 
                  ? 'bg-white text-foreground shadow-sm' 
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {range === 'all' ? 'All' : range}
            </button>
          ))}
        </div>
      </div>
      
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart
            data={data}
            margin={{ top: 5, right: 5, left: -20, bottom: 5 }}
          >
            <defs>
              <linearGradient id="probGradient" x1="0" y1="0" x2="0" y2="1">
                <stop 
                  offset="5%" 
                  stopColor={choice === 'yes' ? '#2b82ea' : '#f87171'} 
                  stopOpacity={0.2} 
                />
                <stop 
                  offset="95%" 
                  stopColor={choice === 'yes' ? '#2b82ea' : '#f87171'} 
                  stopOpacity={0} 
                />
              </linearGradient>
            </defs>
            <CartesianGrid vertical={false} strokeDasharray="3 3" strokeOpacity={0.3} />
            <XAxis 
              dataKey="time" 
              tickLine={false}
              axisLine={false}
              minTickGap={30}
              tick={{ fontSize: 12, fill: '#64748b' }}
            />
            <YAxis 
              tickLine={false}
              axisLine={false}
              domain={[0, 100]}
              ticks={[0, 25, 50, 75, 100]}
              tick={{ fontSize: 12, fill: '#64748b' }}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#fff', 
                border: '1px solid #e2e8f0',
                borderRadius: '0.5rem',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
                fontSize: '12px',
                padding: '8px 12px'
              }}
              formatter={(value: number) => [`${value}%`, 'Probability']}
              labelFormatter={(label) => `Time: ${label}`}
            />
            <Area 
              type="monotone" 
              dataKey="probability" 
              stroke={choice === 'yes' ? '#2b82ea' : '#f87171'} 
              strokeWidth={2}
              fill="url(#probGradient)" 
              animationDuration={500}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default ProbabilityChart;
