
import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

const formSchema = z.object({
  title: z.string().min(5, { message: "Title must be at least 5 characters" }),
  description: z.string().min(10, { message: "Description must be at least 10 characters" }),
  category: z.string().min(2, { message: "Category is required" }),
  endDate: z.string().min(1, { message: "End date is required" }),
});

type FormValues = z.infer<typeof formSchema>;

const CreateEventForm = () => {
  const { user } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      category: "Sports",
      endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().substring(0, 16),
    },
  });

  const onSubmit = async (data: FormValues) => {
    if (!user) {
      toast.error("You must be logged in to create an event");
      return;
    }

    setIsSubmitting(true);

    try {
      // Insert event
      const { data: eventData, error: eventError } = await supabase
        .from("events")
        .insert({
          title: data.title,
          description: data.description,
          category: data.category,
          end_date: new Date(data.endDate).toISOString(),
          created_by: user.id,
        })
        .select()
        .single();

      if (eventError) {
        throw eventError;
      }

      // Insert Yes and No options
      const { error: optionsError } = await supabase
        .from("event_options")
        .insert([
          {
            event_id: eventData.id,
            option_text: "Yes",
            option_type: "yes",
          },
          {
            event_id: eventData.id,
            option_text: "No",
            option_type: "no",
          },
        ]);

      if (optionsError) {
        throw optionsError;
      }

      toast.success("Event created successfully!");
      form.reset();
    } catch (error) {
      console.error("Error creating event:", error);
      toast.error("Failed to create event. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Question Title</FormLabel>
                <FormControl>
                  <Input placeholder="Will Manchester United win the next match?" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Description</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Manchester United will play against Chelsea on Saturday. Will they win?"
                    className="min-h-[100px]"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <FormControl>
                    <Input placeholder="Sports, Politics, Entertainment, etc." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="endDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>End Date</FormLabel>
                  <FormControl>
                    <Input type="datetime-local" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <Separator className="my-4" />

          <Card>
            <CardContent className="pt-6">
              <h3 className="text-sm font-medium mb-4">Default Options</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="border rounded-md p-3 bg-green-50">
                  <p className="font-medium text-green-700">Yes</p>
                </div>
                <div className="border rounded-md p-3 bg-red-50">
                  <p className="font-medium text-red-700">No</p>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                By default, every event has Yes and No options. Users can bet on either option.
              </p>
            </CardContent>
          </Card>

          <Button type="submit" className="w-full" disabled={isSubmitting}>
            {isSubmitting ? "Creating..." : "Create Event"}
          </Button>
        </form>
      </Form>
    </div>
  );
};

export default CreateEventForm;
