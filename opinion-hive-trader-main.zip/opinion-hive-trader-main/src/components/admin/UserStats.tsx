
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { format } from "date-fns";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

interface UserStat {
  id: string;
  username: string | null;
  full_name: string | null;
  avatar_url: string | null;
  balance: number | null;
  bet_count: number;
  total_bets: number;
  created_at?: string;
}

const fetchUserStats = async (): Promise<UserStat[]> => {
  // First get all users
  const { data: profilesData, error: profilesError } = await supabase
    .from("profiles")
    .select("*");

  if (profilesError) {
    throw new Error(profilesError.message);
  }

  const usersWithStats = await Promise.all(
    profilesData.map(async (profile) => {
      // Get bet count for this user
      const { count: betCount, error: betCountError } = await supabase
        .from("user_bets")
        .select("*", { count: "exact", head: true })
        .eq("user_id", profile.id);

      if (betCountError) {
        console.error("Error fetching bet count:", betCountError);
      }

      // Get total bet amount for this user
      const { data: betsData, error: betsError } = await supabase
        .from("user_bets")
        .select("amount")
        .eq("user_id", profile.id);

      let totalBets = 0;
      if (!betsError && betsData) {
        totalBets = betsData.reduce((sum, bet) => sum + (bet.amount || 0), 0);
      } else {
        console.error("Error fetching bet amounts:", betsError);
      }

      return {
        ...profile,
        bet_count: betCount || 0,
        total_bets: totalBets,
      };
    })
  );

  return usersWithStats;
};

const UserStats = () => {
  const {
    data: users,
    isLoading,
    isError,
  } = useQuery({
    queryKey: ["admin-users"],
    queryFn: fetchUserStats,
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-48">
        <div className="flex gap-2">
          <div className="h-3 w-3 rounded-full bg-primary animate-pulse"></div>
          <div className="h-3 w-3 rounded-full bg-primary animate-pulse delay-100"></div>
          <div className="h-3 w-3 rounded-full bg-primary animate-pulse delay-200"></div>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="text-center py-10">
        <p className="text-destructive">Error loading user statistics</p>
      </div>
    );
  }

  // Calculate total balance across all users
  const totalBalance = users?.reduce((sum, user) => sum + (user.balance || 0), 0) || 0;
  
  // Calculate total bet amount
  const totalBetAmount = users?.reduce((sum, user) => sum + user.total_bets, 0) || 0;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{users?.length || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{totalBalance.toFixed(2)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Bet Amount</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{totalBetAmount.toFixed(2)}</div>
          </CardContent>
        </Card>
      </div>
      
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>User</TableHead>
              <TableHead>Balance</TableHead>
              <TableHead>Bet Count</TableHead>
              <TableHead>Total Bet Amount</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {users && users.length > 0 ? (
              users.map((user) => (
                <TableRow key={user.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      <div className="flex flex-col">
                        <span className="font-medium">{user.username || user.full_name || 'Anonymous'}</span>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>₹{(user.balance || 0).toFixed(2)}</TableCell>
                  <TableCell>{user.bet_count}</TableCell>
                  <TableCell>₹{user.total_bets.toFixed(2)}</TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-8">
                  No users found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default UserStats;
