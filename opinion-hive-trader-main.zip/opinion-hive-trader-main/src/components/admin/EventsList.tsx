
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { toast } from "sonner";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Pencil, Trash2 } from "lucide-react";

interface Event {
  id: string;
  title: string;
  description: string;
  category: string;
  start_date: string;
  end_date: string;
  status: string;
  created_at: string;
  bet_count?: number;
}

const fetchEvents = async (): Promise<Event[]> => {
  const { data, error } = await supabase
    .from("events")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) {
    throw new Error(error.message);
  }

  // For each event, get the count of bets
  const eventsWithCounts = await Promise.all(
    data.map(async (event) => {
      const { count, error: countError } = await supabase
        .from("user_bets")
        .select("*", { count: "exact", head: true })
        .eq("event_id", event.id);

      if (countError) {
        console.error("Error fetching bet count:", countError);
        return { ...event, bet_count: 0 };
      }

      return { ...event, bet_count: count || 0 };
    })
  );

  return eventsWithCounts;
};

const EventsList = () => {
  const {
    data: events,
    isLoading,
    isError,
    refetch,
  } = useQuery({
    queryKey: ["admin-events"],
    queryFn: fetchEvents,
  });

  const handleStatusChange = async (eventId: string, newStatus: string) => {
    try {
      const { error } = await supabase
        .from("events")
        .update({ status: newStatus })
        .eq("id", eventId);

      if (error) throw error;
      
      toast.success(`Event ${newStatus === 'active' ? 'activated' : 'deactivated'} successfully`);
      refetch();
    } catch (error) {
      console.error("Error updating event status:", error);
      toast.error("Failed to update event status");
    }
  };
  
  const handleDeleteEvent = async (eventId: string) => {
    try {
      // First delete all options
      const { error: optionsError } = await supabase
        .from("event_options")
        .delete()
        .eq("event_id", eventId);
      
      if (optionsError) throw optionsError;
      
      // Then delete the event
      const { error } = await supabase
        .from("events")
        .delete()
        .eq("id", eventId);
        
      if (error) throw error;
      
      toast.success("Event deleted successfully");
      refetch();
    } catch (error) {
      console.error("Error deleting event:", error);
      toast.error("Failed to delete event");
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-48">
        <div className="flex gap-2">
          <div className="h-3 w-3 rounded-full bg-primary animate-pulse"></div>
          <div className="h-3 w-3 rounded-full bg-primary animate-pulse delay-100"></div>
          <div className="h-3 w-3 rounded-full bg-primary animate-pulse delay-200"></div>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="text-center py-10">
        <p className="text-destructive">Error loading events</p>
        <Button onClick={() => refetch()} variant="outline" className="mt-4">
          Try Again
        </Button>
      </div>
    );
  }

  return (
    <div>
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Title</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>End Date</TableHead>
              <TableHead>Bets</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {events && events.length > 0 ? (
              events.map((event) => (
                <TableRow key={event.id}>
                  <TableCell className="font-medium max-w-[200px] truncate">
                    {event.title}
                  </TableCell>
                  <TableCell>{event.category}</TableCell>
                  <TableCell>
                    {format(new Date(event.end_date), "MMM d, yyyy HH:mm")}
                  </TableCell>
                  <TableCell>{event.bet_count || 0}</TableCell>
                  <TableCell>
                    <Badge
                      variant={event.status === "active" ? "default" : "secondary"}
                    >
                      {event.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleStatusChange(
                          event.id, 
                          event.status === "active" ? "inactive" : "active"
                        )}
                      >
                        {event.status === "active" ? "Deactivate" : "Activate"}
                      </Button>
                      
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="destructive" size="sm">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Event</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to delete this event? This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleDeleteEvent(event.id)}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8">
                  No events found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default EventsList;
