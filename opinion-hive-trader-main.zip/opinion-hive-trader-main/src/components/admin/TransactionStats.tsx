
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";

interface Transaction {
  id: string;
  user_id: string;
  amount: number;
  type: string;
  status: string;
  created_at: string;
  description: string | null;
  profile?: {
    username: string | null;
    full_name: string | null;
  } | null;
}

interface TransactionStats {
  totalDeposits: number;
  totalWithdrawals: number;
  totalBets: number;
  totalWins: number;
}

const fetchTransactions = async (): Promise<{
  transactions: Transaction[];
  stats: TransactionStats;
}> => {
  // First get all transactions
  const { data: transactionsData, error: transactionsError } = await supabase
    .from("transactions")
    .select("*")
    .order("created_at", { ascending: false });

  if (transactionsError) {
    throw new Error(transactionsError.message);
  }

  // Get all profiles to join manually
  const { data: profilesData, error: profilesError } = await supabase
    .from("profiles")
    .select("id, username, full_name");

  if (profilesError) {
    console.error("Error fetching profiles:", profilesError);
  }

  // Map of profile data by user ID
  const profilesMap = (profilesData || []).reduce((map, profile) => {
    map[profile.id] = profile;
    return map;
  }, {} as Record<string, typeof profilesData[0]>);

  // Calculate stats
  const stats = {
    totalDeposits: 0,
    totalWithdrawals: 0,
    totalBets: 0,
    totalWins: 0,
  };

  // Join transactions with profiles manually
  const transactions = (transactionsData || []).map(transaction => {
    // Calculate totals based on transaction type
    const amount = transaction.amount || 0;
    switch (transaction.type) {
      case "deposit":
        stats.totalDeposits += amount;
        break;
      case "withdrawal":
        stats.totalWithdrawals += amount;
        break;
      case "bet":
        stats.totalBets += amount;
        break;
      case "win":
        stats.totalWins += amount;
        break;
    }

    // Join with profile if available
    const profile = transaction.user_id ? profilesMap[transaction.user_id] : null;

    return {
      ...transaction,
      profile: profile ? {
        username: profile.username,
        full_name: profile.full_name
      } : null
    };
  });

  return { transactions, stats };
};

const TransactionStats = () => {
  const {
    data,
    isLoading,
    isError,
  } = useQuery({
    queryKey: ["admin-transactions"],
    queryFn: fetchTransactions,
  });

  const transactions = data?.transactions || [];
  const stats = data?.stats || {
    totalDeposits: 0,
    totalWithdrawals: 0,
    totalBets: 0,
    totalWins: 0,
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-48">
        <div className="flex gap-2">
          <div className="h-3 w-3 rounded-full bg-primary animate-pulse"></div>
          <div className="h-3 w-3 rounded-full bg-primary animate-pulse delay-100"></div>
          <div className="h-3 w-3 rounded-full bg-primary animate-pulse delay-200"></div>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="text-center py-10">
        <p className="text-destructive">Error loading transaction data</p>
      </div>
    );
  }

  // Calculate GGR (Gross Gaming Revenue)
  const ggr = stats.totalBets - stats.totalWins;

  // Calculate net revenue
  const netRevenue = stats.totalDeposits - stats.totalWithdrawals + ggr;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Deposits</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              ₹{stats.totalDeposits.toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">All time deposits</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Withdrawals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              ₹{stats.totalWithdrawals.toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">All time withdrawals</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Bets</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{stats.totalBets.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground mt-1">All time bets placed</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">GGR</CardTitle>
            <CardDescription className="text-xs">Gross Gaming Revenue</CardDescription>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${ggr >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              ₹{ggr.toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Bets - Winnings</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Winnings Paid</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-500">
              ₹{stats.totalWins.toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">All time winnings paid out</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Net Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${netRevenue >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              ₹{netRevenue.toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Deposits - Withdrawals + GGR</p>
          </CardContent>
        </Card>
      </div>
      
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>User</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Description</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {transactions.length > 0 ? (
              transactions.map((transaction) => (
                <TableRow key={transaction.id}>
                  <TableCell className="font-medium">
                    {transaction.profile?.username || transaction.profile?.full_name || transaction.user_id || 'Unknown'}
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        transaction.type === "deposit" ? "default" :
                        transaction.type === "withdrawal" ? "destructive" :
                        transaction.type === "bet" ? "outline" :
                        transaction.type === "win" ? "secondary" : "outline"
                      }
                    >
                      {transaction.type}
                    </Badge>
                  </TableCell>
                  <TableCell className={
                    transaction.type === "deposit" || transaction.type === "win" ? "text-green-600 font-semibold" : "text-red-600 font-semibold"
                  }>
                    ₹{transaction.amount.toFixed(2)}
                  </TableCell>
                  <TableCell>
                    <Badge variant={transaction.status === "completed" ? "default" : "outline"}>
                      {transaction.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {format(new Date(transaction.created_at), "MMM d, yyyy HH:mm")}
                  </TableCell>
                  <TableCell className="text-muted-foreground max-w-[200px] truncate">
                    {transaction.description || '-'}
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8">
                  No transactions found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default TransactionStats;
