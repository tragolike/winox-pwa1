import React from 'react';
import { Link } from 'react-router-dom';
import { Lightbulb } from 'lucide-react'; // Correct icon name
import { motion } from 'framer-motion';

interface EventCardProps {
  id: string;
  category: string;
  title: string;
  image: string;
  hint?: string;
  yesPrice: string;
  noPrice: string;
  endTime: string;
  traders: number;
  volume: string;
}

const EventCard: React.FC<EventCardProps> = ({
  id,
  category,
  title,
  image,
  hint,
  yesPrice,
  noPrice,
  endTime,
  traders,
  volume,
}) => {
  return (
    <Link to={`/event/${id}`} className="block">
      <div className="bg-white rounded-xl overflow-hidden shadow-sm p-4">
        <div className="flex items-start gap-3">
          <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0">
            <img src={image} alt={category} className="w-full h-full object-cover" />
          </div>

          <div className="flex-1">
            <h3 className="font-medium text-gray-900 mb-1">{title}</h3>

            {hint && (
              <div className="flex items-center gap-1 text-xs text-amber-600 mb-2">
                <Lightbulb className="w-3 h-3 text-amber-500" />
                <span>{hint}</span>
              </div>
            )}

            <div className="flex items-center text-xs text-gray-500 mb-2">
              <span className="mr-2">Volume: {volume}</span>
              <span>|</span>
              <span className="mx-2">Traders: {traders}</span>
              <span>|</span>
              <span className="ml-2">Ends: {endTime}</span>
            </div>

            <div className="flex gap-2 mt-2">
              <button className="flex-1 py-2 rounded-lg bg-blue-50 text-blue-500 font-medium text-sm">
                Yes ₹{yesPrice}
              </button>
              <button className="flex-1 py-2 rounded-lg bg-red-50 text-red-500 font-medium text-sm">
                No ₹{noPrice}
              </button>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default EventCard;
