
import React from 'react';
import { cn } from '@/lib/utils';

interface Category {
  id: string;
  name: string;
  icon: React.ReactNode;
}

interface CategorySelectorProps {
  categories: Category[];
  selectedCategory: string;
  onSelectCategory: (categoryId: string) => void;
}

const CategorySelector: React.FC<CategorySelectorProps> = ({
  categories,
  selectedCategory,
  onSelectCategory,
}) => {
  return (
    <div className="overflow-x-auto pb-2 -mx-2 px-2 hide-scrollbar">
      <div className="flex space-x-2">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => onSelectCategory(category.id)}
            className={cn(
              "py-2 px-4 rounded-full whitespace-nowrap text-sm font-medium transition-all duration-200 flex items-center space-x-2",
              selectedCategory === category.id
                ? "bg-primary text-white shadow-md"
                : "bg-muted hover:bg-muted/80 text-muted-foreground"
            )}
          >
            <span className="flex-shrink-0">{category.icon}</span>
            <span>{category.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default CategorySelector;
