
import React from 'react';
import { ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

interface LeaderboardUser {
  id: string;
  name: string;
  amount: number;
  avatar?: string;
  position: number;
  isCurrentUser?: boolean;
}

interface LeaderboardSectionProps {
  title: string;
  users: LeaderboardUser[];
}

const LeaderboardSection: React.FC<LeaderboardSectionProps> = ({ title, users }) => {
  const getPositionColor = (position: number) => {
    switch (position) {
      case 1:
        return 'text-amber-500';
      case 2:
        return 'text-gray-400';
      case 3:
        return 'text-amber-700';
      default:
        return 'text-gray-600';
    }
  };

  const getPositionIcon = (position: number) => {
    switch (position) {
      case 1:
        return (
          <div className="flex-shrink-0 w-12 h-12 flex items-center justify-center">
            <img 
              src="/lovable-uploads/04702312-c9e8-4ec8-bec2-1d75a5830ef2.png" 
              alt="Gold medal" 
              className="w-full h-full object-contain"
            />
          </div>
        );
      case 2:
        return (
          <div className="flex-shrink-0 w-12 h-12 flex items-center justify-center">
            <img 
              src="/lovable-uploads/23fbfcf6-809f-401c-bdf8-13636efcd943.png" 
              alt="Silver medal" 
              className="w-full h-full object-contain"
            />
          </div>
        );
      case 3:
        return (
          <div className="flex-shrink-0 w-12 h-12 flex items-center justify-center">
            <img 
              src="/lovable-uploads/1594af1e-a2de-4c82-bb53-ae22e7a7ac93.png" 
              alt="Bronze medal" 
              className="w-full h-full object-contain"
            />
          </div>
        );
      default:
        return (
          <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-500 text-white flex items-center justify-center">
            <span className="text-sm font-medium">#{position}</span>
          </div>
        );
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <motion.div 
      initial="hidden"
      animate="visible"
      variants={containerVariants}
      className="bg-white rounded-xl overflow-hidden"
    >
      <div className="p-4 flex items-center justify-between">
        <h3 className="font-medium">{title}</h3>
        <Link to="/leaderboard" className="text-sm text-primary flex items-center hover:underline">
          View All <ChevronRight className="w-4 h-4 ml-1" />
        </Link>
      </div>
      
      <div className="divide-y divide-border">
        {users.map((user) => (
          <motion.div 
            key={user.id}
            variants={itemVariants}
            className={`p-3 flex items-center ${user.isCurrentUser ? 'bg-blue-50' : ''}`}
          >
            {getPositionIcon(user.position)}
            
            <div className="ml-3 flex-1">
              <p className="text-sm font-medium line-clamp-1">
                {user.name} 
                {user.isCurrentUser && <span className="text-blue-500 ml-1">(You)</span>}
              </p>
              <p className="text-sm text-muted-foreground">₹{user.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
            </div>
            
            <span className={`text-sm font-medium ${getPositionColor(user.position)}`}>
              #{user.position}
            </span>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default LeaderboardSection;
