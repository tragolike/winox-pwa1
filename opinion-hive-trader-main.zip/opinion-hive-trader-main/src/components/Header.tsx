
import React from 'react';
import { Link } from 'react-router-dom';
import { Wallet } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import Notifications from './Notifications';
import WinoxLogo from './WinoxLogo';

const Header = () => {
  const { profile, user } = useAuth();

  return (
    <header className="bg-white p-4 flex items-center justify-between shadow-sm">
      <WinoxLogo />
      
      <div className="flex items-center gap-3">
        <div className="bg-white rounded-full border border-gray-200 px-3 py-1 flex items-center">
          <Wallet className="h-4 w-4 text-gray-500 mr-2" />
          <span className="text-sm font-medium">₹{profile?.balance || 0}</span>
        </div>
        
        <Notifications />
        
        <Link to="/profile" className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
          <span className="text-sm font-medium text-blue-500">
            {profile?.username?.[0]?.toUpperCase() || (user?.email && user.email[0].toUpperCase()) || 'W'}
          </span>
        </Link>
      </div>
    </header>
  );
};

export default Header;
