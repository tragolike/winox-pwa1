
import React from 'react';
import { Link } from 'react-router-dom';
import { Home, Search, Briefcase, BarChart2, User } from 'lucide-react';

interface BottomNavigationProps {
  activeTab: 'home' | 'search' | 'portfolio' | 'leaderboard' | 'profile';
}

const BottomNavigation: React.FC<BottomNavigationProps> = ({ activeTab }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 h-16 bg-white border-t border-gray-200 flex items-center justify-around z-50">
      <Link to="/" className={`flex flex-col items-center justify-center w-full h-full ${activeTab === 'home' ? 'text-blue-500' : 'text-gray-400'}`}>
        <Home size={22} />
        <span className="text-xs mt-1">Home</span>
      </Link>
      
      <Link to="/search" className={`flex flex-col items-center justify-center w-full h-full ${activeTab === 'search' ? 'text-blue-500' : 'text-gray-400'}`}>
        <Search size={22} />
        <span className="text-xs mt-1">Search</span>
      </Link>
      
      <Link to="/portfolio" className={`flex flex-col items-center justify-center w-full h-full ${activeTab === 'portfolio' ? 'text-blue-500' : 'text-gray-400'}`}>
        <Briefcase size={22} />
        <span className="text-xs mt-1">Portfolio</span>
      </Link>
      
      <Link to="/leaderboard" className={`flex flex-col items-center justify-center w-full h-full ${activeTab === 'leaderboard' ? 'text-blue-500' : 'text-gray-400'}`}>
        <BarChart2 size={22} />
        <span className="text-xs mt-1">Leaderboard</span>
      </Link>
      
      <Link to="/profile" className={`flex flex-col items-center justify-center w-full h-full ${activeTab === 'profile' ? 'text-blue-500' : 'text-gray-400'}`}>
        <User size={22} />
        <span className="text-xs mt-1">Profile</span>
      </Link>
    </div>
  );
};

export default BottomNavigation;
