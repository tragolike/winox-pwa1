
import React, { useState, useEffect } from 'react';
import { X, Plus, Minus, Edit } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';

interface TradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  event: {
    id: string;
    title: string;
    image: string;
    yesPrice: number;
    noPrice: number;
  };
  choice: 'yes' | 'no';
}

const TradeModal: React.FC<TradeModalProps> = ({
  isOpen,
  onClose,
  event,
  choice,
}) => {
  const [quantity, setQuantity] = useState(1);
  const [price, setPrice] = useState(choice === 'yes' ? event.yesPrice : event.noPrice);
  const [sliderValue, setSliderValue] = useState(50);
  
  const minPrice = Math.max((choice === 'yes' ? event.yesPrice : event.noPrice) * 0.8, 1);
  const maxPrice = Math.min((choice === 'yes' ? event.yesPrice : event.noPrice) * 1.2, 10);
  
  const handleQuantityChange = (newQuantity: number) => {
    if (newQuantity >= 1 && newQuantity <= 100) {
      setQuantity(newQuantity);
    }
  };
  
  const handlePriceSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value, 10);
    setSliderValue(value);
    
    // Calculate price based on slider position
    const newPrice = minPrice + ((maxPrice - minPrice) * value / 100);
    setPrice(parseFloat(newPrice.toFixed(1)));
  };
  
  const totalCost = price * quantity;
  const potentialReturn = choice === 'yes' ? quantity * 10 : quantity * 10;
  
  // Reset values when choice changes
  useEffect(() => {
    setPrice(choice === 'yes' ? event.yesPrice : event.noPrice);
    setQuantity(1);
    setSliderValue(50);
  }, [choice, event.yesPrice, event.noPrice]);
  
  if (!isOpen) return null;
  
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 backdrop-blur-sm p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="bg-white rounded-2xl overflow-hidden shadow-xl w-full max-w-md relative"
          >
            <div className="p-4 border-b border-border">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-foreground">Place Trade</h3>
                <button 
                  onClick={onClose}
                  className="p-1 rounded-full hover:bg-muted transition-colors"
                >
                  <X className="w-5 h-5 text-muted-foreground" />
                </button>
              </div>
            </div>
            
            <div className="p-4">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-muted rounded-lg overflow-hidden flex items-center justify-center">
                  <img src={event.image} alt="" className="w-full h-full object-cover" />
                </div>
                <h4 className="text-base font-medium text-foreground">{event.title}</h4>
              </div>
              
              <div className="flex gap-2 mb-6">
                <button 
                  className={cn(
                    "flex-1 py-3 rounded-md font-medium transition-colors text-center",
                    choice === 'yes' 
                      ? "bg-yes text-white" 
                      : "bg-yes-light text-yes"
                  )}
                >
                  Yes ₹{event.yesPrice}
                </button>
                <button 
                  className={cn(
                    "flex-1 py-3 rounded-md font-medium transition-colors text-center",
                    choice === 'no' 
                      ? "bg-no text-white" 
                      : "bg-no-light text-no"
                  )}
                >
                  No ₹{event.noPrice}
                </button>
              </div>
              
              <div className="space-y-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium text-foreground">Price</label>
                    <div className="text-sm text-muted-foreground">
                      {choice === 'yes' 
                        ? `Available Qty: ${Math.floor(Math.random() * 10000)}`
                        : `Available Qty: ${Math.floor(Math.random() * 10000)}`
                      }
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <button 
                      onClick={() => setPrice(Math.max(price - 0.5, minPrice))}
                      className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors"
                    >
                      <Minus className="w-4 h-4 text-foreground" />
                    </button>
                    
                    <div className="flex-1 mx-4">
                      <input
                        type="range"
                        min="0"
                        max="100"
                        value={sliderValue}
                        onChange={handlePriceSliderChange}
                        className="w-full h-2 bg-muted rounded-full appearance-none cursor-pointer"
                        style={{
                          background: `linear-gradient(to right, ${choice === 'yes' ? '#2b82ea' : '#f87171'} 0%, ${choice === 'yes' ? '#2b82ea' : '#f87171'} ${sliderValue}%, #e5e7eb ${sliderValue}%, #e5e7eb 100%)`,
                        }}
                      />
                    </div>
                    
                    <button 
                      onClick={() => setPrice(Math.min(price + 0.5, maxPrice))}
                      className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors"
                    >
                      <Plus className="w-4 h-4 text-foreground" />
                    </button>
                  </div>
                  
                  <div className="flex justify-end">
                    <span className="text-xl font-semibold">₹{price.toFixed(1)}</span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Quantity</label>
                  
                  <div className="flex items-center justify-between">
                    <button 
                      onClick={() => handleQuantityChange(quantity - 1)}
                      className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors"
                    >
                      <Minus className="w-4 h-4 text-foreground" />
                    </button>
                    
                    <div className="flex-1 mx-4 relative">
                      <input
                        type="number"
                        value={quantity}
                        onChange={(e) => handleQuantityChange(parseInt(e.target.value, 10) || 1)}
                        className="w-full h-10 bg-white border border-border rounded-md text-center text-base font-medium"
                        min="1"
                        max="100"
                      />
                      <button className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors">
                        <Edit className="w-4 h-4" />
                      </button>
                    </div>
                    
                    <button 
                      onClick={() => handleQuantityChange(quantity + 1)}
                      className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors"
                    >
                      <Plus className="w-4 h-4 text-foreground" />
                    </button>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-border">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-muted-foreground">You put in</span>
                    <span className="text-base font-semibold">₹{totalCost.toFixed(2)}</span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">You get</span>
                    <span className="text-base font-semibold text-green-600">₹{potentialReturn.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="p-4 bg-muted/30">
              <button 
                className={cn(
                  "w-full py-3 rounded-md font-semibold text-white transition-colors flex items-center justify-center gap-2",
                  choice === 'yes' ? "bg-yes hover:bg-yes-hover" : "bg-no hover:bg-no-hover"
                )}
              >
                <span>Swipe for {choice === 'yes' ? 'Yes' : 'No'}</span>
              </button>
              
              <div className="text-xs text-center mt-4 text-muted-foreground">
                <span>Commission: 5%</span>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default TradeModal;
