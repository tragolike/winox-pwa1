
import React from 'react';
import { Wallet, Clock, TrendingUp, UserCheck } from 'lucide-react';
import { motion } from 'framer-motion';

interface WalletWidgetProps {
  balance: number;
  onDeposit: () => void;
}

const WalletWidget: React.FC<WalletWidgetProps> = ({ balance, onDeposit }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: 0.1 }}
      className="bg-white rounded-xl border border-border shadow-sm overflow-hidden"
    >
      <div className="p-4">
        <h3 className="text-sm font-medium text-muted-foreground mb-2">Wallet Balance</h3>
        
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
            <Wallet className="w-5 h-5 text-primary" />
          </div>
          <div>
            <span className="text-2xl font-bold">₹{balance.toFixed(2)}</span>
          </div>
        </div>
        
        <div className="mt-4">
          <button 
            onClick={onDeposit}
            className="w-full py-2.5 bg-primary text-white rounded-lg font-medium hover:bg-primary/90 transition-colors"
          >
            Add Money
          </button>
        </div>
      </div>
      
      <div className="bg-muted/30 p-4 border-t border-border">
        <h4 className="text-sm font-medium mb-3">Quick Stats</h4>
        
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-2">
                <TrendingUp className="w-4 h-4 text-green-600" />
              </div>
              <span className="text-sm">Winning Rate</span>
            </div>
            <span className="text-sm font-medium">68%</span>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-2">
                <Clock className="w-4 h-4 text-blue-600" />
              </div>
              <span className="text-sm">Active Trades</span>
            </div>
            <span className="text-sm font-medium">3</span>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center mr-2">
                <UserCheck className="w-4 h-4 text-purple-600" />
              </div>
              <span className="text-sm">Referral Bonus</span>
            </div>
            <span className="text-sm font-medium">₹15.50</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default WalletWidget;
